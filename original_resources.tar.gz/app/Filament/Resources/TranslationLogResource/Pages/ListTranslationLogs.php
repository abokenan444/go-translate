<?php

namespace App\Filament\Resources\TranslationLogResource\Pages;

use App\Filament\Resources\TranslationLogResource;
use Filament\Resources\Pages\ListRecords;

class ListTranslationLogs extends ListRecords
{
    protected static string $resource = TranslationLogResource::class;
}
