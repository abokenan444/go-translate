<?php

namespace App\Services;

use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;

class SSOService
{
    public function handleLogin(string $provider, array $payload)
    {
        $email = $payload['email'] ?? null;
        
        if (!$email) {
            throw new \Exception("Invalid SSO Payload: Email missing");
        }

        $user = User::firstOrCreate(
            ['email' => $email],
            [
                'name' => $payload['name'] ?? 'Enterprise User',
                'password' => bcrypt(Str::random(32)),
                'sso_provider' => $provider,
                'sso_id' => $payload['sub'] ?? Str::uuid(),
                'email_verified_at' => now(),
            ]
        );

        Auth::login($user);

        return $user;
    }

    public function getMetadata(): string
    {
        return '<?xml version="1.0"?><EntityDescriptor entityID="https://culturaltranslate.com/sso/metadata">...</EntityDescriptor>';
    }
}
