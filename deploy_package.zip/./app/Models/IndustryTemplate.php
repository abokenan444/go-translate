<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class IndustryTemplate extends Model
{
    protected $table = 'industry_templates';

    protected $fillable = [
        'industry_code',
        'industry_name',
        'industry_name_en',
        'description',
        'common_terms',
        'glossary',
        'preferred_tones',
        'cultural_considerations',
        'content_types',
        'system_prompt',
        'translation_rules',
        'quality_criteria',
        'example_translations',
        'seo_keywords',
        'marketing_phrases',
        'icon',
        'color',
        'is_active',
        'priority',
    ];

    protected $casts = [
        'is_active' => 'boolean',
        'priority' => 'integer',
    ];
}
