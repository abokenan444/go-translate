<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Str;

class JobPosting extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'title',
        'slug',
        'description',
        'responsibilities',
        'requirements',
        'benefits',
        'department',
        'location',
        'employment_type',
        'experience_level',
        'salary_range',
        'positions_available',
        'status',
        'application_deadline',
        'required_skills',
        'nice_to_have_skills',
        'meta_title',
        'meta_description',
        'meta_keywords',
        'views_count',
        'applications_count',
        'published_at',
    ];

    protected $casts = [
        'required_skills' => 'array',
        'nice_to_have_skills' => 'array',
        'meta_keywords' => 'array',
        'application_deadline' => 'date',
        'published_at' => 'datetime',
    ];

    protected static function boot()
    {
        parent::boot();
        
        static::creating(function ($job) {
            if (empty($job->slug)) {
                $job->slug = Str::slug($job->title);
            }
        });
        
        static::updating(function ($job) {
            if ($job->isDirty('title') && empty($job->slug)) {
                $job->slug = Str::slug($job->title);
            }
        });
    }

    public function applications()
    {
        return $this->hasMany(JobApplication::class);
    }

    public function scopePublished($query)
    {
        return $query->where('status', 'published')
            ->where(function ($q) {
                $q->whereNull('application_deadline')
                  ->orWhere('application_deadline', '>=', now());
            });
    }

    public function scopeOpen($query)
    {
        return $query->published();
    }

    public function isOpen(): bool
    {
        if ($this->status !== 'published') {
            return false;
        }
        
        if ($this->application_deadline && $this->application_deadline->isPast()) {
            return false;
        }
        
        return true;
    }

    public function incrementViews(): void
    {
        $this->increment('views_count');
    }

    public function incrementApplications(): void
    {
        $this->increment('applications_count');
    }

    public function getRouteKeyName()
    {
        return 'slug';
    }
}
