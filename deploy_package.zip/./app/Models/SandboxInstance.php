<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class SandboxInstance extends Model
{
    protected $fillable = [
        'user_id',
        'company_name',
        'company_slug',
        'subdomain',
        'status',
        'brand_profile_id',
        'industry_profile',
        'target_markets',
        'tone',
        'brand_values',
        'preferred_terms',
        'forbidden_terms',
        'glossary_id',
        'memory_id',
        'project_id',
        'preview_url',
        'is_public_preview',
        'rate_limit_profile',
        'expires_at',
    ];

    protected $casts = [
        'industry_profile' => 'array',
        'target_markets' => 'array',
        'brand_values' => 'array',
        'preferred_terms' => 'array',
        'forbidden_terms' => 'array',
        'is_public_preview' => 'boolean',
        'expires_at' => 'datetime',
    ];

    // Relationships
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function brandProfile(): BelongsTo
    {
        return $this->belongsTo(BrandProfile::class);
    }

    public function glossary(): BelongsTo
    {
        return $this->belongsTo(Glossary::class);
    }

    public function translationMemory(): BelongsTo
    {
        return $this->belongsTo(TranslationMemory::class, 'memory_id');
    }

    public function project(): BelongsTo
    {
        return $this->belongsTo(Project::class);
    }

    public function apiKeys(): HasMany
    {
        return $this->hasMany(SandboxApiKey::class);
    }

    public function pages(): HasMany
    {
        return $this->hasMany(SandboxPage::class);
    }

    public function webhookEndpoints(): HasMany
    {
        return $this->hasMany(SandboxWebhookEndpoint::class);
    }

    public function webhookLogs(): HasMany
    {
        return $this->hasMany(SandboxWebhookLog::class);
    }

    // Scopes
    public function scopeActive($query)
    {
        return $query->where('status', 'active');
    }

    public function scopeExpired($query)
    {
        return $query->where('status', 'expired');
    }

    public function scopeNotExpired($query)
    {
        return $query->where(function ($q) {
            $q->whereNull('expires_at')
              ->orWhere('expires_at', '>', now());
        });
    }

    // Helpers
    public function isExpired(): bool
    {
        return $this->expires_at && $this->expires_at->isPast();
    }

    public function isActive(): bool
    {
        return $this->status === 'active' && !$this->isExpired();
    }

    public function getFullSubdomainUrl(): string
    {
        return "https://{$this->subdomain}.integration.culturaltranslate.com";
    }
}
