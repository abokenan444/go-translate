<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\FilamentServiceProvider::class,
    App\Providers\Filament\AdminPanelProvider::class,
    App\Providers\Filament\SuperAdminPanelProvider::class,
    App\Providers\ViewServiceProvider::class,
];
