<?php

return [
    // Meta & SEO
    'site_title' => 'منصة الترجمة الثقافية - CulturalTranslate',
    'site_description' => 'منصة متقدمة للترجمة الثقافية باستخدام الذكاء الاصطناعي',
    
    // Hero Section
    'hero_title' => 'منصة الترجمة الثقافية بالذكاء الاصطناعي',
    'hero_subtitle' => 'ترجمة المحتوى مع الحفاظ على السياق الثقافي وصوت العلامة التجارية والمعنى',
    'hero_cta_start' => 'ابدأ الآن',
    'hero_cta_discover' => 'اكتشف المزيد',
    'hero_no_credit_card' => 'بدون بطاقة ائتمان',
    'hero_free_trial' => 'تجربة مجانية',
    
    // Stats Section
    'stats_registered_users' => 'المستخدمون المسجلون',
    'stats_active_subscriptions' => 'الاشتراكات النشطة',
    'stats_published_pages' => 'الصفحات المنشورة',
    'stats_active_companies' => 'الشركات النشطة',
    
    // Demo Section
    'demo_title' => 'جرّب الترجمة الثقافية الآن',
    'demo_subtitle' => 'اختبر قوة الترجمة الذكية مع الحفاظ على السياق الثقافي',
    'demo_from' => 'من',
    'demo_to' => 'إلى',
    'demo_source_text' => 'النص الأصلي',
    'demo_translation' => 'الترجمة',
    'demo_placeholder' => 'أدخل النص للترجمة...',
    'demo_result_placeholder' => 'ستظهر الترجمة هنا...',
    'demo_translate_btn' => 'ترجمة الآن',
    'demo_translating' => 'جاري الترجمة...',
    'demo_free_trial_note' => '💡 تجربة مجانية - لا حاجة لبطاقة ائتمان',
    'demo_try_examples' => 'جرّب هذه الأمثلة:',
    'demo_example_welcome' => 'مثال: رسالة ترحيب',
    'demo_example_marketing' => 'مثال: تسويقي',
    'demo_example_support' => 'مثال: خدمة عملاء',
    'demo_error_empty' => 'الرجاء إدخال نص للترجمة',
    'demo_error_same_lang' => 'الرجاء اختيار لغات مختلفة',
    
    // Demo Features
    'demo_feature_instant' => 'ترجمة فورية',
    'demo_feature_instant_desc' => 'احصل على ترجمات دقيقة في ثوانٍ',
    'demo_feature_cultural' => 'سياق ثقافي',
    'demo_feature_cultural_desc' => 'ترجمة تحترم الثقافات المختلفة',
    'demo_feature_secure' => 'آمن ومحمي',
    'demo_feature_secure_desc' => 'بياناتك محمية بالكامل',
    
    // Features Section
    'features_title' => 'مميزات قوية',
    'features_subtitle' => 'كل ما تحتاجه لترجمة المحتوى مع الحفاظ على السياق الثقافي وصوت العلامة التجارية',
    
    'feature_cultural_title' => 'التكيف الثقافي',
    'feature_cultural_desc' => 'الحفاظ على السياق الثقافي المدعوم بالذكاء الاصطناعي يضمن أن رسالتك تلقى صدى لدى الجماهير المحلية',
    
    'feature_fast_title' => 'سريع للغاية',
    'feature_fast_desc' => 'ترجمة آلاف الكلمات في ثوانٍ باستخدام نماذج الذكاء الاصطناعي المحسّنة',
    
    'feature_security_title' => 'أمان المؤسسات',
    'feature_security_desc' => 'متوافق مع GDPR، معتمد SOC 2 Type II، مع تشفير من طرف إلى طرف',
    
    'feature_memory_title' => 'ذاكرة الترجمة',
    'feature_memory_desc' => 'وفر التكاليف من خلال إعادة استخدام الترجمات السابقة والحفاظ على الاتساق',
    
    'feature_glossary_title' => 'مسارد مخصصة',
    'feature_glossary_desc' => 'حدد المصطلحات الخاصة بالعلامة التجارية للحصول على ترجمات متسقة',
    
    'feature_api_title' => 'API صديق للمطورين',
    'feature_api_desc' => 'RESTful API مع SDKs بلغات متعددة وتوثيق شامل',
    
    // CTA Section
    'cta_title' => 'هل أنت مستعد للانطلاق عالمياً؟',
    'cta_subtitle' => 'انضم إلى منصة الترجمة الثقافية للوصول إلى جماهير عالمية',
    'cta_button' => 'ابدأ الآن',
    
    // Languages
    'lang_english' => 'English',
    'lang_arabic' => 'العربية',
    'lang_spanish' => 'Español',
    'lang_french' => 'Français',
    'lang_german' => 'Deutsch',
    'lang_italian' => 'Italiano',
    'lang_portuguese' => 'Português',
    'lang_russian' => 'Русский',
    'lang_chinese' => '中文',
    'lang_japanese' => '日本語',
    'lang_korean' => '한국어',
    'lang_turkish' => 'Türkçe',
    'lang_dutch' => 'Nederlands',
    
    // Dashboard
    'dashboard' => [
        'overview' => 'نظرة عامة',
        'translate' => 'ترجمة',
        'history' => 'السجل',
        'projects' => 'المشاريع',
        'subscription' => 'الاشتراك',
        'settings' => 'الإعدادات',
        
        // Stats
        'stats' => [
            'translations' => 'الترجمات',
            'characters' => 'الأحرف',
            'characters_used' => 'الأحرف المستخدمة',
            'active_projects' => 'المشاريع النشطة',
            'team_members' => 'أعضاء الفريق',
            'projects' => 'المشاريع',
            'active' => 'نشط',
        ],
        
        // Translate Tab
        'source_language' => 'اللغة المصدر',
        'target_language' => 'اللغة المستهدفة',
        'source_text' => 'النص المصدر',
        'translated_text' => 'النص المترجم',
        'translate_button' => 'ترجمة',
        'translating' => 'جاري الترجمة...',
        'clear' => 'مسح',
        'copy' => 'نسخ',
        'download' => 'تحميل',
        
        // History Tab
        'recent_translations' => 'الترجمات الأخيرة',
        'no_history' => 'لا يوجد سجل ترجمات بعد',
        'date' => 'التاريخ',
        'from' => 'من',
        'to' => 'إلى',
        'text' => 'النص',
        'actions' => 'الإجراءات',
        
        // Projects Tab
        'my_projects' => 'مشاريعي',
        'create_project' => 'إنشاء مشروع',
        'no_projects' => 'لا توجد مشاريع بعد',
        'project_name' => 'اسم المشروع',
        'description' => 'الوصف',
        'created_at' => 'تاريخ الإنشاء',
        
        // Subscription Tab
        'current_plan' => 'الخطة الحالية',
        'upgrade' => 'ترقية',
        'usage' => 'الاستخدام',
        'billing' => 'الفواتير',
        'cancel_subscription' => 'إلغاء الاشتراك',
        
        // Settings Tab
        'profile' => 'الملف الشخصي',
        'account' => 'الحساب',
        'security' => 'الأمان',
        'notifications' => 'الإشعارات',
        'api_keys' => 'مفاتيح API',
        'save_changes' => 'حفظ التغييرات',
        'cancel' => 'إلغاء',
    ],
];
