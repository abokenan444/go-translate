@extends('layouts.app')

@section('title', 'Careers - Join Our Team | Cultural Translate Platform')
@section('meta_description', 'Explore exciting career opportunities at Cultural Translate Platform. We are looking for talented individuals to join our mission of breaking language barriers through AI-powered culturally-aware translation technology.')

@push('meta')
<meta name="keywords" content="careers, jobs, cultural translate, translation jobs, AI jobs, remote work, tech careers, software engineer jobs, product manager jobs, design jobs">
<meta property="og:title" content="Careers at Cultural Translate Platform - Join Our Team">
<meta property="og:description" content="Join our mission to revolutionize global communication through culturally-aware AI translation. Explore open positions and apply today.">
<meta property="og:type" content="website">
<meta property="og:url" content="{{ url()->current() }}">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="Careers at Cultural Translate Platform">
<meta name="twitter:description" content="Join our mission to revolutionize global communication through culturally-aware AI translation.">
<link rel="canonical" href="{{ route('careers.index') }}">
@endpush

@section('content')
<div class="min-h-screen bg-gradient-to-b from-gray-50 to-white">
    <!-- Hero Section -->
    <section class="relative bg-gradient-to-r from-blue-600 to-indigo-700 text-white py-20 px-4">
        <div class="max-w-7xl mx-auto">
            <div class="text-center max-w-4xl mx-auto">
                <h1 class="text-5xl md:text-6xl font-bold mb-6 leading-tight">
                    Build the Future of Global Communication
                </h1>
                <p class="text-xl md:text-2xl mb-8 text-blue-100">
                    Join Cultural Translate Platform and help break down language barriers with AI-powered, culturally-aware translation technology trusted by thousands worldwide.
                </p>
                <div class="flex flex-wrap justify-center gap-4 mb-12">
                    <span class="px-6 py-3 bg-white/20 backdrop-blur-sm rounded-full text-lg">🌍 Remote-First</span>
                    <span class="px-6 py-3 bg-white/20 backdrop-blur-sm rounded-full text-lg">💡 Innovation-Driven</span>
                    <span class="px-6 py-3 bg-white/20 backdrop-blur-sm rounded-full text-lg">🚀 Fast-Growing</span>
                    <span class="px-6 py-3 bg-white/20 backdrop-blur-sm rounded-full text-lg">🤝 Collaborative</span>
                </div>
            </div>
        </div>
    </section>

    <!-- Why Join Us Section -->
    <section class="py-16 px-4">
        <div class="max-w-7xl mx-auto">
            <h2 class="text-4xl font-bold text-center mb-4">Why Work With Us?</h2>
            <p class="text-xl text-gray-600 text-center mb-12 max-w-3xl mx-auto">
                At Cultural Translate Platform, we're not just building translation software—we're revolutionizing how the world communicates across cultures and languages. Join us in our mission to make global communication accessible, accurate, and culturally respectful for everyone.
            </p>
            
            <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                <div class="bg-white p-8 rounded-xl shadow-lg hover:shadow-xl transition-shadow">
                    <div class="text-4xl mb-4">🎯</div>
                    <h3 class="text-2xl font-semibold mb-3">Meaningful Impact</h3>
                    <p class="text-gray-600">
                        Your work directly impacts millions of users worldwide, helping businesses expand globally and individuals connect across language barriers. Every feature you build breaks down walls between cultures and enables cross-cultural understanding.
                    </p>
                </div>

                <div class="bg-white p-8 rounded-xl shadow-lg hover:shadow-xl transition-shadow">
                    <div class="text-4xl mb-4">🧠</div>
                    <h3 class="text-2xl font-semibold mb-3">Cutting-Edge Technology</h3>
                    <p class="text-gray-600">
                        Work with the latest AI and machine learning technologies, including GPT-4, Azure Cognitive Services, and custom NLP models. We invest heavily in R&D and encourage experimentation with emerging technologies to stay ahead of the curve.
                    </p>
                </div>

                <div class="bg-white p-8 rounded-xl shadow-lg hover:shadow-xl transition-shadow">
                    <div class="text-4xl mb-4">🌟</div>
                    <h3 class="text-2xl font-semibold mb-3">Professional Growth</h3>
                    <p class="text-gray-600">
                        We provide comprehensive learning budgets, conference attendance, certification programs, and mentorship from industry leaders. Your career growth is our priority, with clear advancement paths and skill development opportunities.
                    </p>
                </div>

                <div class="bg-white p-8 rounded-xl shadow-lg hover:shadow-xl transition-shadow">
                    <div class="text-4xl mb-4">⚖️</div>
                    <h3 class="text-2xl font-semibold mb-3">Work-Life Balance</h3>
                    <p class="text-gray-600">
                        Flexible working hours, remote-first culture, unlimited PTO policy, and comprehensive health benefits. We believe in sustainable productivity and support your wellbeing with mental health resources and wellness programs.
                    </p>
                </div>

                <div class="bg-white p-8 rounded-xl shadow-lg hover:shadow-xl transition-shadow">
                    <div class="text-4xl mb-4">💰</div>
                    <h3 class="text-2xl font-semibold mb-3">Competitive Compensation</h3>
                    <p class="text-gray-600">
                        Industry-leading salaries, equity options, performance bonuses, and comprehensive benefits package. We regularly benchmark against top tech companies to ensure fair and competitive compensation for all roles.
                    </p>
                </div>

                <div class="bg-white p-8 rounded-xl shadow-lg hover:shadow-xl transition-shadow">
                    <div class="text-4xl mb-4">🌈</div>
                    <h3 class="text-2xl font-semibold mb-3">Diverse & Inclusive</h3>
                    <p class="text-gray-600">
                        Our team spans 20+ countries and speaks over 30 languages. We celebrate diversity and foster an inclusive environment where everyone's voice matters and unique perspectives drive innovation and better products.
                    </p>
                </div>
            </div>
        </div>
    </section>

    <!-- Open Positions Section -->
    <section class="py-16 px-4 bg-gray-50">
        <div class="max-w-7xl mx-auto">
            <h2 class="text-4xl font-bold text-center mb-4">Open Positions</h2>
            <p class="text-xl text-gray-600 text-center mb-12">
                Find your next career opportunity and join our growing team
            </p>

            <!-- Filters -->
            <div class="mb-8 flex flex-wrap gap-4 justify-center">
                <select class="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                    <option value="">All Departments</option>
                    @foreach($departments as $dept)
                        <option value="{{ $dept }}">{{ $dept }}</option>
                    @endforeach
                </select>
                
                <select class="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                    <option value="">All Locations</option>
                    @foreach($locations as $loc)
                        <option value="{{ $loc }}">{{ $loc }}</option>
                    @endforeach
                </select>
            </div>

            <!-- Job Listings -->
            @if($jobs->count() > 0)
                <div class="space-y-6">
                    @foreach($jobs as $job)
                        <a href="{{ route('careers.show', $job->slug) }}" class="block bg-white p-6 rounded-xl shadow-md hover:shadow-xl transition-all hover:-translate-y-1">
                            <div class="flex flex-wrap justify-between items-start gap-4">
                                <div class="flex-1">
                                    <h3 class="text-2xl font-semibold text-gray-900 mb-2">{{ $job->title }}</h3>
                                    <div class="flex flex-wrap gap-3 mb-3">
                                        @if($job->department)
                                            <span class="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm font-medium">{{ $job->department }}</span>
                                        @endif
                                        <span class="px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm font-medium">{{ $job->location }}</span>
                                        <span class="px-3 py-1 bg-purple-100 text-purple-800 rounded-full text-sm font-medium">{{ ucfirst(str_replace('-', ' ', $job->employment_type)) }}</span>
                                        <span class="px-3 py-1 bg-orange-100 text-orange-800 rounded-full text-sm font-medium">{{ ucfirst($job->experience_level) }} Level</span>
                                    </div>
                                    <p class="text-gray-600 line-clamp-2">{{ Str::limit(strip_tags($job->description), 200) }}</p>
                                </div>
                                <div class="flex flex-col items-end gap-2">
                                    @if($job->salary_range)
                                        <span class="text-lg font-semibold text-green-600">{{ $job->salary_range }}</span>
                                    @endif
                                    <span class="text-blue-600 font-medium hover:underline">View Details →</span>
                                </div>
                            </div>
                        </a>
                    @endforeach
                </div>

                <div class="mt-8">
                    {{ $jobs->links() }}
                </div>
            @else
                <div class="text-center py-12">
                    <div class="text-6xl mb-4">📭</div>
                    <h3 class="text-2xl font-semibold text-gray-700 mb-2">No open positions at the moment</h3>
                    <p class="text-gray-600">Check back soon or send us your resume for future opportunities</p>
                </div>
            @endif
        </div>
    </section>

    <!-- Company Values Section -->
    <section class="py-16 px-4">
        <div class="max-w-7xl mx-auto">
            <h2 class="text-4xl font-bold text-center mb-12">Our Core Values</h2>
            <div class="grid md:grid-cols-4 gap-6">
                <div class="text-center">
                    <div class="text-5xl mb-4">🚀</div>
                    <h4 class="text-xl font-semibold mb-2">Innovation First</h4>
                    <p class="text-gray-600">We constantly push boundaries and embrace new technologies to solve complex problems.</p>
                </div>
                <div class="text-center">
                    <div class="text-5xl mb-4">🤝</div>
                    <h4 class="text-xl font-semibold mb-2">Collaboration</h4>
                    <p class="text-gray-600">We believe the best solutions come from diverse teams working together toward shared goals.</p>
                </div>
                <div class="text-center">
                    <div class="text-5xl mb-4">🎯</div>
                    <h4 class="text-xl font-semibold mb-2">User-Centric</h4>
                    <p class="text-gray-600">Every decision we make is guided by our commitment to delivering value to our users.</p>
                </div>
                <div class="text-center">
                    <div class="text-5xl mb-4">📈</div>
                    <h4 class="text-xl font-semibold mb-2">Continuous Growth</h4>
                    <p class="text-gray-600">We invest in our people's development and celebrate learning from both successes and failures.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- CTA Section -->
    <section class="py-16 px-4 bg-gradient-to-r from-blue-600 to-indigo-700 text-white">
        <div class="max-w-4xl mx-auto text-center">
            <h2 class="text-4xl font-bold mb-6">Don't See the Perfect Role?</h2>
            <p class="text-xl mb-8 text-blue-100">
                We're always looking for talented individuals. Send us your resume and let us know how you can contribute to our mission.
            </p>
            <a href="mailto:careers@culturaltranslate.com" class="inline-block px-8 py-4 bg-white text-blue-600 rounded-lg font-semibold hover:bg-blue-50 transition-colors text-lg">
                Get in Touch
            </a>
        </div>
    </section>
</div>
@endsection
