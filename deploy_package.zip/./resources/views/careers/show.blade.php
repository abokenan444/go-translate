@extends('layouts.app')

@section('title', $job->meta_title ?? $job->title . ' - Careers | Cultural Translate Platform')
@section('meta_description', $job->meta_description ?? Str::limit(strip_tags($job->description), 160))

@push('meta')
<meta name="keywords" content="{{ $job->meta_keywords ? implode(', ', $job->meta_keywords) : 'careers, jobs, ' . $job->title }}">
<meta property="og:title" content="{{ $job->title }} at Cultural Translate Platform">
<meta property="og:description" content="{{ Str::limit(strip_tags($job->description), 200) }}">
<meta property="og:type" content="website">
<meta property="og:url" content="{{ url()->current() }}">
<link rel="canonical" href="{{ route('careers.show', $job->slug) }}">

<!-- JSON-LD Schema for Job Posting -->
<script type="application/ld+json">
{
  "@context": "https://schema.org/",
  "@type": "JobPosting",
  "title": "{{ $job->title }}",
  "description": "{{ strip_tags($job->description) }}",
  "identifier": {
    "@type": "PropertyValue",
    "name": "Cultural Translate Platform",
    "value": "{{ $job->id }}"
  },
  "datePosted": "{{ $job->published_at?->toIso8601String() ?? $job->created_at->toIso8601String() }}",
  @if($job->application_deadline)
  "validThrough": "{{ $job->application_deadline->toIso8601String() }}",
  @endif
  "employmentType": "{{ strtoupper(str_replace('-', '_', $job->employment_type)) }}",
  "hiringOrganization": {
    "@type": "Organization",
    "name": "Cultural Translate Platform",
    "sameAs": "{{ url('/') }}",
    "logo": "{{ asset('images/logo.png') }}"
  },
  "jobLocation": {
    "@type": "Place",
    "address": {
      "@type": "PostalAddress",
      "addressLocality": "{{ $job->location }}"
    }
  },
  @if($job->salary_range)
  "baseSalary": {
    "@type": "MonetaryAmount",
    "currency": "USD",
    "value": {
      "@type": "QuantitativeValue",
      "value": "{{ $job->salary_range }}"
    }
  },
  @endif
  "responsibilities": "{{ strip_tags($job->responsibilities ?? $job->description) }}",
  "qualifications": "{{ strip_tags($job->requirements ?? '') }}"
}
</script>
@endpush

@section('content')
<div class="min-h-screen bg-gray-50">
    <!-- Header -->
    <div class="bg-white border-b">
        <div class="max-w-5xl mx-auto px-4 py-8">
            <a href="{{ route('careers.index') }}" class="inline-flex items-center text-blue-600 hover:text-blue-700 mb-6">
                <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
                </svg>
                Back to Careers
            </a>

            <h1 class="text-4xl md:text-5xl font-bold text-gray-900 mb-4">{{ $job->title }}</h1>
            
            <div class="flex flex-wrap gap-3 mb-6">
                @if($job->department)
                    <span class="px-4 py-2 bg-blue-100 text-blue-800 rounded-full font-medium">📂 {{ $job->department }}</span>
                @endif
                <span class="px-4 py-2 bg-green-100 text-green-800 rounded-full font-medium">📍 {{ $job->location }}</span>
                <span class="px-4 py-2 bg-purple-100 text-purple-800 rounded-full font-medium">⏰ {{ ucfirst(str_replace('-', ' ', $job->employment_type)) }}</span>
                <span class="px-4 py-2 bg-orange-100 text-orange-800 rounded-full font-medium">🎯 {{ ucfirst($job->experience_level) }} Level</span>
                @if($job->salary_range)
                    <span class="px-4 py-2 bg-green-600 text-white rounded-full font-medium">💰 {{ $job->salary_range }}</span>
                @endif
            </div>

            @if($job->application_deadline)
                <p class="text-gray-600">
                    <strong>Application Deadline:</strong> {{ $job->application_deadline->format('F j, Y') }}
                    ({{ $job->application_deadline->diffForHumans() }})
                </p>
            @endif
        </div>
    </div>

    <div class="max-w-5xl mx-auto px-4 py-12">
        <div class="grid lg:grid-cols-3 gap-8">
            <!-- Main Content -->
            <div class="lg:col-span-2 space-y-8">
                <!-- Description -->
                <section class="bg-white rounded-xl p-8 shadow-md">
                    <h2 class="text-2xl font-bold mb-4">About This Role</h2>
                    <div class="prose max-w-none text-gray-700">
                        {!! $job->description !!}
                    </div>
                </section>

                @if($job->responsibilities)
                <!-- Responsibilities -->
                <section class="bg-white rounded-xl p-8 shadow-md">
                    <h2 class="text-2xl font-bold mb-4">Key Responsibilities</h2>
                    <div class="prose max-w-none text-gray-700">
                        @php
                            $responsibilities = is_string($job->responsibilities) ? json_decode($job->responsibilities, true) : $job->responsibilities;
                        @endphp
                        @if(is_array($responsibilities))
                            <ul class="list-disc pl-5 space-y-2">
                                @foreach($responsibilities as $item)
                                    <li>{{ $item }}</li>
                                @endforeach
                            </ul>
                        @else
                            {!! $job->responsibilities !!}
                        @endif
                    </div>
                </section>
                @endif

                @if($job->requirements)
                <!-- Requirements -->
                <section class="bg-white rounded-xl p-8 shadow-md">
                    <h2 class="text-2xl font-bold mb-4">Requirements</h2>
                    <div class="prose max-w-none text-gray-700">
                        @php
                            $requirements = is_string($job->requirements) ? json_decode($job->requirements, true) : $job->requirements;
                        @endphp
                        @if(is_array($requirements))
                            <ul class="list-disc pl-5 space-y-2">
                                @foreach($requirements as $item)
                                    <li>{{ $item }}</li>
                                @endforeach
                            </ul>
                        @else
                            {!! $job->requirements !!}
                        @endif
                    </div>
                </section>
                @endif

                @if($job->required_skills || $job->nice_to_have_skills)
                <!-- Skills -->
                <section class="bg-white rounded-xl p-8 shadow-md">
                    <h2 class="text-2xl font-bold mb-4">Skills</h2>
                    
                    @if($job->required_skills)
                        <div class="mb-4">
                            <h3 class="text-lg font-semibold mb-2">Required Skills:</h3>
                            <div class="flex flex-wrap gap-2">
                                @foreach($job->required_skills as $skill)
                                    <span class="px-3 py-1 bg-red-100 text-red-800 rounded-full text-sm">{{ $skill }}</span>
                                @endforeach
                            </div>
                        </div>
                    @endif
                    
                    @if($job->nice_to_have_skills)
                        <div>
                            <h3 class="text-lg font-semibold mb-2">Nice to Have:</h3>
                            <div class="flex flex-wrap gap-2">
                                @foreach($job->nice_to_have_skills as $skill)
                                    <span class="px-3 py-1 bg-gray-100 text-gray-800 rounded-full text-sm">{{ $skill }}</span>
                                @endforeach
                            </div>
                        </div>
                    @endif
                </section>
                @endif

                @if($job->benefits)
                <!-- Benefits -->
                <section class="bg-white rounded-xl p-8 shadow-md">
                    <h2 class="text-2xl font-bold mb-4">What We Offer</h2>
                    <div class="prose max-w-none text-gray-700">
                        @php
                            $benefits = is_string($job->benefits) ? json_decode($job->benefits, true) : $job->benefits;
                        @endphp
                        @if(is_array($benefits))
                            <ul class="list-disc pl-5 space-y-2">
                                @foreach($benefits as $item)
                                    <li>{{ $item }}</li>
                                @endforeach
                            </ul>
                        @else
                            {!! $job->benefits !!}
                        @endif
                    </div>
                </section>
                @endif

                <!-- Application Form -->
                <section id="apply-form" class="bg-white rounded-xl p-8 shadow-md">
                    <h2 class="text-2xl font-bold mb-6">Apply for This Position</h2>
                    
                    @if(session('success'))
                        <div class="mb-6 p-4 bg-green-100 border border-green-400 text-green-700 rounded-lg">
                            {{ session('success') }}
                        </div>
                    @endif

                    @if(session('error'))
                        <div class="mb-6 p-4 bg-red-100 border border-red-400 text-red-700 rounded-lg">
                            {{ session('error') }}
                        </div>
                    @endif

                    <form action="{{ route('careers.apply', $job->slug) }}" method="POST" enctype="multipart/form-data" class="space-y-6">
                        @csrf

                        <!-- Personal Information -->
                        <div class="grid md:grid-cols-2 gap-4">
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Full Name *</label>
                                <input type="text" name="full_name" required value="{{ old('full_name') }}" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 @error('full_name') border-red-500 @enderror">
                                @error('full_name')<span class="text-red-500 text-sm">{{ $message }}</span>@enderror
                            </div>

                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Email *</label>
                                <input type="email" name="email" required value="{{ old('email') }}" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 @error('email') border-red-500 @enderror">
                                @error('email')<span class="text-red-500 text-sm">{{ $message }}</span>@enderror
                            </div>

                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Phone *</label>
                                <input type="tel" name="phone" required value="{{ old('phone') }}" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 @error('phone') border-red-500 @enderror">
                                @error('phone')<span class="text-red-500 text-sm">{{ $message }}</span>@enderror
                            </div>

                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">LinkedIn Profile</label>
                                <input type="url" name="linkedin_url" value="{{ old('linkedin_url') }}" placeholder="https://linkedin.com/in/yourprofile" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 @error('linkedin_url') border-red-500 @enderror">
                                @error('linkedin_url')<span class="text-red-500 text-sm">{{ $message }}</span>@enderror
                            </div>

                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Portfolio URL</label>
                                <input type="url" name="portfolio_url" value="{{ old('portfolio_url') }}" placeholder="https://yourportfolio.com" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 @error('portfolio_url') border-red-500 @enderror">
                                @error('portfolio_url')<span class="text-red-500 text-sm">{{ $message }}</span>@enderror
                            </div>

                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Years of Experience</label>
                                <input type="number" name="years_of_experience" value="{{ old('years_of_experience') }}" min="0" max="50" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 @error('years_of_experience') border-red-500 @enderror">
                                @error('years_of_experience')<span class="text-red-500 text-sm">{{ $message }}</span>@enderror
                            </div>
                        </div>

                        <!-- Professional Information -->
                        <div class="grid md:grid-cols-2 gap-4">
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Current Position</label>
                                <input type="text" name="current_position" value="{{ old('current_position') }}" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                            </div>

                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Current Company</label>
                                <input type="text" name="current_company" value="{{ old('current_company') }}" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                            </div>

                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Expected Salary (USD)</label>
                                <input type="number" name="expected_salary" value="{{ old('expected_salary') }}" min="0" step="1000" placeholder="80000" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                            </div>

                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Notice Period</label>
                                <input type="text" name="notice_period" value="{{ old('notice_period') }}" placeholder="e.g., 2 weeks, 1 month" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                            </div>
                        </div>

                        <!-- Cover Letter -->
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Cover Letter</label>
                            <textarea name="cover_letter" rows="6" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" placeholder="Tell us why you're interested in this role and what makes you a great fit...">{{ old('cover_letter') }}</textarea>
                        </div>

                        <!-- Resume Upload -->
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Resume / CV * (PDF, DOC, DOCX - Max 5MB)</label>
                            <input type="file" name="resume" required accept=".pdf,.doc,.docx" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 @error('resume') border-red-500 @enderror">
                            @error('resume')<span class="text-red-500 text-sm">{{ $message }}</span>@enderror
                        </div>

                        <!-- Additional Documents -->
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Additional Documents (Optional)</label>
                            <input type="file" name="additional_documents[]" multiple accept=".pdf,.doc,.docx,.jpg,.jpeg,.png" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                            <p class="text-sm text-gray-500 mt-1">You can upload certifications, portfolio samples, etc. (Max 5MB each)</p>
                        </div>

                        <!-- Additional Info -->
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Additional Information</label>
                            <textarea name="additional_info" rows="4" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" placeholder="Anything else you'd like us to know?">{{ old('additional_info') }}</textarea>
                        </div>

                        <!-- Submit Button -->
                        <div class="flex items-center gap-4">
                            <button type="submit" class="px-8 py-3 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700 transition-colors">
                                Submit Application
                            </button>
                            <p class="text-sm text-gray-500">* Required fields</p>
                        </div>
                    </form>
                </section>
            </div>

            <!-- Sidebar -->
            <div class="lg:col-span-1">
                <div class="sticky top-8 space-y-6">
                    <!-- Quick Apply -->
                    <div class="bg-blue-600 text-white rounded-xl p-6 shadow-md">
                        <h3 class="text-xl font-bold mb-3">Ready to Apply?</h3>
                        <p class="mb-4 text-blue-100">Join our team and make an impact</p>
                        <a href="#apply-form" class="block w-full px-6 py-3 bg-white text-blue-600 rounded-lg font-semibold text-center hover:bg-blue-50 transition-colors">
                            Apply Now
                        </a>
                    </div>

                    <!-- Job Stats -->
                    <div class="bg-white rounded-xl p-6 shadow-md">
                        <h3 class="text-lg font-semibold mb-4">Job Details</h3>
                        <dl class="space-y-3">
                            <div>
                                <dt class="text-sm text-gray-600">Posted</dt>
                                <dd class="font-medium">{{ $job->published_at?->diffForHumans() ?? $job->created_at->diffForHumans() }}</dd>
                            </div>
                            <div>
                                <dt class="text-sm text-gray-600">Positions</dt>
                                <dd class="font-medium">{{ $job->positions_available }} {{ Str::plural('opening', $job->positions_available) }}</dd>
                            </div>
                            <div>
                                <dt class="text-sm text-gray-600">Applications</dt>
                                <dd class="font-medium">{{ $job->applications_count }}</dd>
                            </div>
                        </dl>
                    </div>

                    <!-- Share -->
                    <div class="bg-white rounded-xl p-6 shadow-md">
                        <h3 class="text-lg font-semibold mb-4">Share This Job</h3>
                        <div class="flex gap-2">
                            <a href="https://www.linkedin.com/sharing/share-offsite/?url={{ urlencode(url()->current()) }}" target="_blank" class="flex-1 px-4 py-2 bg-blue-700 text-white rounded-lg text-center hover:bg-blue-800">
                                LinkedIn
                            </a>
                            <a href="https://twitter.com/intent/tweet?url={{ urlencode(url()->current()) }}&text={{ urlencode($job->title) }}" target="_blank" class="flex-1 px-4 py-2 bg-sky-500 text-white rounded-lg text-center hover:bg-sky-600">
                                Twitter
                            </a>
                        </div>
                    </div>

                    <!-- Related Jobs -->
                    @if($relatedJobs->count() > 0)
                    <div class="bg-white rounded-xl p-6 shadow-md">
                        <h3 class="text-lg font-semibold mb-4">Related Positions</h3>
                        <div class="space-y-4">
                            @foreach($relatedJobs as $related)
                                <a href="{{ route('careers.show', $related->slug) }}" class="block group">
                                    <h4 class="font-medium text-gray-900 group-hover:text-blue-600 transition-colors">{{ $related->title }}</h4>
                                    <p class="text-sm text-gray-600">{{ $related->location }} • {{ ucfirst(str_replace('-', ' ', $related->employment_type)) }}</p>
                                </a>
                            @endforeach
                        </div>
                    </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
