@extends('layouts.docs')

@section('content')
    <h1 class="text-3xl font-bold mb-4">Introduction</h1>
    <p class="text-lg text-gray-700 mb-6">
        Welcome to the Cultural Translate API documentation. Our API allows you to integrate culturally aware translation into your applications, ensuring your content resonates with local audiences.
    </p>

    <div class="bg-blue-50 border-l-4 border-blue-500 p-4 mb-6">
        <p class="text-blue-700">
            <strong>Note:</strong> This is the enterprise documentation. For sandbox testing, please refer to the Sandbox API guide.
        </p>
    </div>

    <h2 class="text-2xl font-bold mt-8 mb-4">Key Features</h2>
    <ul class="list-disc pl-6 space-y-2 text-gray-700">
        <li><strong>Cultural Awareness:</strong> Translations that respect local idioms and customs.</li>
        <li><strong>Quality Scoring:</strong> Real-time evaluation of translation quality.</li>
        <li><strong>Enterprise Security:</strong> SSO, Role-Based Access, and Audit Logs.</li>
    </ul>
@endsection
