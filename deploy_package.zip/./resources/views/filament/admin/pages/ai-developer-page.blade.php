<x-filament-panels::page>
    <div class="text-center">
        <p>جاري التحويل إلى نظام AI Developer...</p>
    </div>
</x-filament-panels::page>
