<x-filament-widgets::widget>
    <x-filament::section>
        <div class="flex justify-end">
            <x-language-switcher />
        </div>
    </x-filament::section>
</x-filament-widgets::widget>
