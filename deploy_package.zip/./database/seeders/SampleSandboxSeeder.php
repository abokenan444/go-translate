<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Str;
use App\Models\SandboxInstance;
use App\Models\SandboxApiKey;
use App\Models\SandboxPage;
use App\Models\SandboxSiteTemplate;

class SampleSandboxSeeder extends Seeder
{
    public function run(): void
    {
        $template = SandboxSiteTemplate::first();
        if (! $template) {
            $template = SandboxSiteTemplate::create([
                'name' => 'Default SaaS',
                'slug' => 'default-saas',
                'config' => [
                    'sections' => ['hero', 'features', 'pricing', 'faq'],
                ],
            ]);
        }

        $subdomain = 'demo-' . Str::lower(Str::random(6));

        $instance = SandboxInstance::updateOrCreate(
            ['subdomain' => $subdomain],
            [
                'name' => 'Demo Sandbox',
                'template_id' => $template->id,
                'status' => 'active',
                'expires_at' => now()->addDays(7),
            ]
        );

        SandboxApiKey::updateOrCreate(
            ['sandbox_instance_id' => $instance->id, 'scope' => 'full'],
            [
                'key' => Str::uuid()->toString(),
                'last_used_at' => null,
            ]
        );

        SandboxPage::updateOrCreate(
            ['sandbox_instance_id' => $instance->id, 'path' => '/'],
            [
                'title' => 'Welcome',
                'original_content' => '<h1>Welcome to Demo</h1><p>This is a demo sandbox.</p>',
                'translated_content' => null,
            ]
        );

        $this->command->info('Sample sandbox created: ' . $subdomain);
        $this->command->info('Preview URL: https://' . $subdomain . '.integration.culturaltranslate.com/');
    }
}
