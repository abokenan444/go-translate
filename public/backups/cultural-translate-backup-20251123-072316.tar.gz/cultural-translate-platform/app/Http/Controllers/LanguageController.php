<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Session;

class LanguageController extends Controller
{
    /**
     * Switch application language
     */
    public function switch($locale)
    {
        // Validate locale
        $supportedLocales = ['ar', 'en', 'fr', 'es', 'de', 'it', 'pt', 'ru', 'zh', 'ja', 'ko', 'tr', 'nl'];
        
        if (!in_array($locale, $supportedLocales)) {
            $locale = 'en';
        }
        
        // Set locale
        App::setLocale($locale);
        Session::put('locale', $locale);
        
        return redirect()->back();
    }
}
