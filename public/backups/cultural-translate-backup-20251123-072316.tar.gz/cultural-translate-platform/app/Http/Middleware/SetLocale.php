<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Session;

class SetLocale
{
    /**
     * Handle an incoming request.
     */
    public function handle(Request $request, Closure $next)
    {
        // Get locale from session or browser
        $locale = Session::get('locale');
        
        if (!$locale) {
            // Try to get from browser
            $locale = $request->getPreferredLanguage(['ar', 'en', 'fr', 'es', 'de', 'it', 'pt', 'ru', 'zh', 'ja', 'ko', 'tr', 'nl']);
            
            if (!$locale) {
                $locale = 'en'; // Default
            }
            
            Session::put('locale', $locale);
        }
        
        App::setLocale($locale);
        
        return $next($request);
    }
}
