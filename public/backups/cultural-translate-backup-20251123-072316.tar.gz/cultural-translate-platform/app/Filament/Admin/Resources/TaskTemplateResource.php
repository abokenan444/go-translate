<?php

namespace App\Filament\Admin\Resources;

use App\Filament\Admin\Resources\TaskTemplateResource\Pages;
use App\Filament\Admin\Resources\TaskTemplateResource\RelationManagers;
use App\Models\TaskTemplate;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletingScope;

class TaskTemplateResource extends Resource
{
    protected static ?string $model = TaskTemplate::class;

    protected static ?string $navigationIcon = 'heroicon-o-rectangle-stack';

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Forms\Components\Textarea::make('task_code')
                    ->required()
                    ->columnSpanFull(),
                Forms\Components\Textarea::make('task_name')
                    ->required()
                    ->columnSpanFull(),
                Forms\Components\Textarea::make('task_name_en')
                    ->required()
                    ->columnSpanFull(),
                Forms\Components\Textarea::make('category')
                    ->required()
                    ->columnSpanFull(),
                Forms\Components\Textarea::make('type')
                    ->required()
                    ->columnSpanFull(),
                Forms\Components\Textarea::make('description')
                    ->columnSpanFull(),
                Forms\Components\Textarea::make('system_prompt')
                    ->required()
                    ->columnSpanFull(),
                Forms\Components\Textarea::make('user_prompt_template')
                    ->required()
                    ->columnSpanFull(),
                Forms\Components\Textarea::make('recommended_tones')
                    ->columnSpanFull(),
                Forms\Components\Textarea::make('recommended_industries')
                    ->columnSpanFull(),
                Forms\Components\TextInput::make('estimated_tokens')
                    ->numeric()
                    ->default(500),
                Forms\Components\Textarea::make('example_input')
                    ->columnSpanFull(),
                Forms\Components\Textarea::make('example_output')
                    ->columnSpanFull(),
                Forms\Components\TextInput::make('is_active')
                    ->numeric()
                    ->default(1),
                Forms\Components\TextInput::make('is_featured')
                    ->numeric()
                    ->default(0),
                Forms\Components\TextInput::make('priority')
                    ->numeric()
                    ->default(0),
                Forms\Components\Textarea::make('slug')
                    ->columnSpanFull(),
                Forms\Components\Textarea::make('base_prompt')
                    ->columnSpanFull(),
                Forms\Components\Textarea::make('default_source_lang')
                    ->columnSpanFull(),
                Forms\Components\Textarea::make('default_target_lang')
                    ->columnSpanFull(),
                Forms\Components\Textarea::make('default_tone_slug')
                    ->columnSpanFull(),
                Forms\Components\Textarea::make('default_industry_slug')
                    ->columnSpanFull(),
                Forms\Components\Textarea::make('default_culture_slug')
                    ->columnSpanFull(),
                Forms\Components\Textarea::make('meta')
                    ->columnSpanFull(),
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('estimated_tokens')
                    ->numeric()
                    ->sortable(),
                Tables\Columns\TextColumn::make('is_active')
                    ->numeric()
                    ->sortable(),
                Tables\Columns\TextColumn::make('is_featured')
                    ->numeric()
                    ->sortable(),
                Tables\Columns\TextColumn::make('priority')
                    ->numeric()
                    ->sortable(),
                Tables\Columns\TextColumn::make('created_at')
                    ->dateTime()
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
                Tables\Columns\TextColumn::make('updated_at')
                    ->dateTime()
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
            ])
            ->filters([
                //
            ])
            ->actions([
                Tables\Actions\EditAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListTaskTemplates::route('/'),
            'create' => Pages\CreateTaskTemplate::route('/create'),
            'edit' => Pages\EditTaskTemplate::route('/{record}/edit'),
        ];
    }
}
