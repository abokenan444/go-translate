<?php

namespace App\Filament\Admin\Resources\CulturalProfileResource\Pages;

use App\Filament\Admin\Resources\CulturalProfileResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateCulturalProfile extends CreateRecord
{
    protected static string $resource = CulturalProfileResource::class;
}
