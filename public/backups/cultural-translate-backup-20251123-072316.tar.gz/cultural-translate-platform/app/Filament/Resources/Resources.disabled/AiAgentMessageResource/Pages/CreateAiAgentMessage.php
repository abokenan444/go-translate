<?php

namespace App\Filament\Resources\AiAgentMessageResource\Pages;

use App\Filament\Resources\AiAgentMessageResource;
use Filament\Resources\Pages\CreateRecord;

class CreateAiAgentMessage extends CreateRecord
{
    protected static string $resource = AiAgentMessageResource::class;
}
