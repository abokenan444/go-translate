<?php

namespace App\Filament\Resources\PlanComparisonResource\Pages;

use App\Filament\Resources\PlanComparisonResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreatePlanComparison extends CreateRecord
{
    protected static string $resource = PlanComparisonResource::class;
}
