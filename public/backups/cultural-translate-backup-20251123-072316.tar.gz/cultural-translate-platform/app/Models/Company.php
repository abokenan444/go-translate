<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Company extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'email',
        'phone',
        'address',
        'logo',
        'website',
        'description',
        'is_active',
        'subscription_plan_id',
        'subscription_start',
        'subscription_end',
        'max_users',
        'settings',
    ];

    protected $casts = [
        'is_active' => 'boolean',
        'subscription_start' => 'date',
        'subscription_end' => 'date',
        'settings' => 'array',
    ];

    public function subscriptionPlan(): BelongsTo
    {
        return $this->belongsTo(SubscriptionPlan::class);
    }

    public function users(): HasMany
    {
        return $this->hasMany(User::class);
    }

    public function employees(): HasMany
    {
        return $this->hasMany(User::class)->whereNotNull('company_role');
    }

    public function isSubscriptionActive(): bool
    {
        if (!$this->subscription_end) {
            return false;
        }
        return $this->subscription_end->isFuture() && $this->is_active;
    }

    public function canAddMoreUsers(): bool
    {
        return $this->users()->count() < $this->max_users;
    }

    public function remainingUsers(): int
    {
        return max(0, $this->max_users - $this->users()->count());
    }
}
