<?php

namespace App\Services;

use OpenAI\Client;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Cache;

class AdvancedTranslationService
{
    protected $client;
    protected $culturalEngine;
    protected $cacheManager;
    
    public function __construct()
    {
        $apiKey = env('OPENAI_API_KEY') ?? config('services.openai.key');
        $this->client = \OpenAI::client($apiKey);
        $this->culturalEngine = new CulturalAdaptationEngine();
        $this->cacheManager = new TranslationCacheManager();
    }
    
    /**
     * Advanced translation with cultural adaptation
     */
    public function translate(array $params): array
    {
        $startTime = microtime(true);
        
        // Extract parameters
        $text = $params['text'];
        $sourceLang = $params['source_language'];
        $targetLang = $params['target_language'];
        $tone = $params['tone'] ?? 'professional';
        $industry = $params['industry'] ?? null;
        $taskType = $params['task_type'] ?? null;
        $context = $params['context'] ?? null;
        
        // Check cache first
        $cacheKey = $this->cacheManager->generateKey($text, $sourceLang, $targetLang, $tone, $industry);
        $cached = $this->cacheManager->get($cacheKey);
        
        if ($cached) {
            return [
                'success' => true,
                'translated_text' => $cached['translated_text'],
                'source_language' => $sourceLang,
                'target_language' => $targetLang,
                'tone' => $tone,
                'word_count' => str_word_count($text),
                'tokens_used' => 0, // Cached, no tokens used
                'cached' => true,
                'response_time_ms' => round((microtime(true) - $startTime) * 1000, 2),
            ];
        }
        
        try {
            // Load cultural profiles
            $sourceProfile = $this->culturalEngine->getProfile($sourceLang);
            $targetProfile = $this->culturalEngine->getProfile($targetLang);
            
            // Load emotional tone
            $toneProfile = $this->culturalEngine->getTone($tone);
            
            // Load industry template if provided
            $industryTemplate = $industry ? $this->culturalEngine->getIndustry($industry) : null;
            
            // Load task template if provided
            $taskTemplate = $taskType ? $this->culturalEngine->getTaskTemplate($taskType) : null;
            
            // Build advanced prompt
            $prompt = $this->buildAdvancedPrompt([
                'text' => $text,
                'source_profile' => $sourceProfile,
                'target_profile' => $targetProfile,
                'tone_profile' => $toneProfile,
                'industry_template' => $industryTemplate,
                'task_template' => $taskTemplate,
                'context' => $context,
            ]);
            
            // Call OpenAI API
            $response = $this->client->chat()->create([
                'model' => 'gpt-4',
                'messages' => [
                    [
                        'role' => 'system',
                        'content' => $prompt['system_message']
                    ],
                    [
                        'role' => 'user',
                        'content' => $prompt['user_message']
                    ]
                ],
                'temperature' => 0.3,
                'max_tokens' => 4000,
            ]);
            
            $translatedText = trim($response->choices[0]->message->content ?? '');
            $tokensUsed = $response->usage->totalTokens ?? 0;
            
            // Post-processing
            $translatedText = $this->postProcess($translatedText, $targetProfile);
            
            // Quality check
            $qualityScore = $this->calculateQuality($text, $translatedText, $sourceLang, $targetLang);
            
            $responseTime = round((microtime(true) - $startTime) * 1000, 2);
            
            // Cache the result
            $this->cacheManager->store($cacheKey, [
                'translated_text' => $translatedText,
                'quality_score' => $qualityScore,
                'tokens_used' => $tokensUsed,
                'response_time_ms' => $responseTime,
            ]);
            
            return [
                'success' => true,
                'translated_text' => $translatedText,
                'source_language' => $sourceLang,
                'target_language' => $targetLang,
                'tone' => $tone,
                'word_count' => str_word_count($text),
                'tokens_used' => $tokensUsed,
                'quality_score' => $qualityScore,
                'cached' => false,
                'response_time_ms' => $responseTime,
            ];
            
        } catch (\Exception $e) {
            return [
                'success' => false,
                'error' => $e->getMessage(),
                'response_time_ms' => round((microtime(true) - $startTime) * 1000, 2),
            ];
        }
    }
    
    /**
     * Build advanced culturally-aware prompt
     */
    protected function buildAdvancedPrompt(array $data): array
    {
        $sourceProfile = $data['source_profile'];
        $targetProfile = $data['target_profile'];
        $toneProfile = $data['tone_profile'];
        $industryTemplate = $data['industry_template'];
        $taskTemplate = $data['task_template'];
        $context = $data['context'];
        $text = $data['text'];
        
        // Build system message
        $systemParts = [];
        
        // Base instruction
        $systemParts[] = "You are CulturalTranslate, an advanced AI translation engine specialized in cultural adaptation.";
        
        // Target culture instructions
        if ($targetProfile) {
            $systemParts[] = "\n**Target Culture:** " . $targetProfile['culture_name'];
            $systemParts[] = $targetProfile['system_prompt'];
            $systemParts[] = "\n**Translation Guidelines:** " . $targetProfile['translation_guidelines'];
        }
        
        // Tone instructions
        if ($toneProfile) {
            $systemParts[] = "\n**Tone:** " . $toneProfile['tone_name_en'];
            $systemParts[] = $toneProfile['system_instructions'];
        }
        
        // Industry-specific instructions
        if ($industryTemplate) {
            $systemParts[] = "\n**Industry:** " . $industryTemplate['industry_name_en'];
            $systemParts[] = $industryTemplate['system_prompt'];
        }
        
        // Task-specific instructions
        if ($taskTemplate) {
            $systemParts[] = "\n**Task Type:** " . $taskTemplate['task_name_en'];
            $systemParts[] = $taskTemplate['system_prompt'];
        }
        
        $systemMessage = implode("\n", $systemParts);
        
        // Build user message
        $userMessage = "Translate the following text with full cultural adaptation:\n\n";
        
        if ($context) {
            $userMessage .= "**Context:** $context\n\n";
        }
        
        $userMessage .= "**Text to translate:**\n$text\n\n";
        $userMessage .= "Provide ONLY the translated text without any explanations or notes.";
        
        return [
            'system_message' => $systemMessage,
            'user_message' => $userMessage,
        ];
    }
    
    /**
     * Post-process translated text
     */
    protected function postProcess(string $text, ?array $targetProfile): string
    {
        // Remove common AI artifacts
        $text = preg_replace('/^(Here is the translation:|Translation:|Translated text:)/i', '', $text);
        $text = preg_replace('/\n\n+/', "\n\n", $text);
        $text = trim($text);
        
        // Apply text direction if needed
        if ($targetProfile && $targetProfile['text_direction'] === 'rtl') {
            // Add RTL markers if needed
            $text = "\u{202B}" . $text . "\u{202C}";
        }
        
        return $text;
    }
    
    /**
     * Calculate translation quality score
     */
    protected function calculateQuality(string $source, string $translation, string $sourceLang, string $targetLang): float
    {
        $score = 100;
        
        // Length ratio check (translation shouldn't be too different in length)
        $sourceLen = mb_strlen($source);
        $transLen = mb_strlen($translation);
        $ratio = $transLen / max($sourceLen, 1);
        
        if ($ratio < 0.5 || $ratio > 2.0) {
            $score -= 20;
        }
        
        // Check for untranslated text (same as source)
        if ($source === $translation) {
            $score -= 50;
        }
        
        // Check for empty translation
        if (empty(trim($translation))) {
            $score = 0;
        }
        
        return max(0, min(100, $score));
    }
    
    /**
     * Detect language of text
     */
    public function detectLanguage(string $text): array
    {
        try {
            $response = $this->client->chat()->create([
                'model' => 'gpt-4',
                'messages' => [
                    [
                        'role' => 'system',
                        'content' => 'You are a language detection expert. Respond with ONLY the ISO 639-1 language code (e.g., en, ar, fr).'
                    ],
                    [
                        'role' => 'user',
                        'content' => "Detect the language of this text:\n\n$text"
                    ]
                ],
                'temperature' => 0.1,
                'max_tokens' => 10,
            ]);
            
            $detectedLang = trim($response->choices[0]->message->content ?? 'en');
            
            return [
                'success' => true,
                'language' => $detectedLang,
            ];
            
        } catch (\Exception $e) {
            return [
                'success' => false,
                'error' => $e->getMessage(),
                'language' => 'en',
            ];
        }
    }
}
