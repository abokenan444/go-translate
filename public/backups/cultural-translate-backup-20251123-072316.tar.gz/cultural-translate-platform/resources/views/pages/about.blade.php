<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>من نحن - CulturalTranslate</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">
    <!-- Header -->
    <header class="bg-white shadow-sm">
        <nav class="container mx-auto px-6 py-4">
            <div class="flex items-center justify-between">
                <a href="/" class="text-2xl font-bold text-indigo-600">Cultural Translate</a>
                <div class="hidden md:flex items-center space-x-reverse space-x-8">
                    <a href="/" class="text-gray-700 hover:text-indigo-600">الرئيسية</a>
                    <a href="/features" class="text-gray-700 hover:text-indigo-600">المميزات</a>
                    <a href="/pricing" class="text-gray-700 hover:text-indigo-600">الأسعار</a>
                    <a href="/use-cases" class="text-gray-700 hover:text-indigo-600">حالات الاستخدام</a>
                    <a href="/api-docs" class="text-gray-700 hover:text-indigo-600">API Docs</a>
                    <a href="/about" class="text-indigo-600 font-semibold">من نحن</a>
                    <a href="/contact" class="text-gray-700 hover:text-indigo-600">اتصل بنا</a>
                </div>
            </div>
        </nav>
    </header>

    <!-- Hero Section -->
    <section class="bg-gradient-to-r from-indigo-600 to-purple-600 text-white py-20">
        <div class="container mx-auto px-6 text-center">
            <h1 class="text-5xl font-bold mb-4">من نحن</h1>
            <p class="text-xl">كسر حواجز اللغة بترجمة مدعومة بالذكاء الاصطناعي تفهم الثقافة</p>
        </div>
    </section>

    <!-- Mission Section -->
    <section class="py-20">
        <div class="container mx-auto px-6">
            <div class="max-w-3xl mx-auto text-center">
                <h2 class="text-4xl font-bold text-gray-900 mb-6">مهمتنا</h2>
                <p class="text-xl text-gray-700 leading-relaxed">
                    نؤمن بأن اللغة يجب ألا تكون عائقاً أمام التواصل العالمي. مهمتنا هي تزويد الشركات والأفراد بتكنولوجيا ترجمة لا تحول الكلمات فحسب، بل تحافظ أيضاً على الفروق الثقافية الدقيقة وصوت العلامة التجارية والسياق العاطفي.
                </p>
            </div>
        </div>
    </section>

    <!-- Story Section -->
    <section class="bg-gray-100 py-20">
        <div class="container mx-auto px-6">
            <div class="max-w-4xl mx-auto">
                <h2 class="text-4xl font-bold text-gray-900 mb-8 text-center">قصتنا</h2>
                <div class="bg-white rounded-lg shadow-lg p-8">
                    <p class="text-lg text-gray-700 leading-relaxed mb-6">
                        تأسست منصة CulturalTranslate في عام 2024 من ملاحظة بسيطة: أدوات الترجمة التقليدية كانت تفشل الشركات التي تحاول التوسع عالمياً. كانت تستطيع ترجمة الكلمات، لكنها لم تستطع التقاط السياق الثقافي الذي يجعل التواصل فعالاً حقاً.
                    </p>
                    <p class="text-lg text-gray-700 leading-relaxed">
                        مؤسسونا، فريق من اللغويين وباحثي الذكاء الاصطناعي ورواد الأعمال، اجتمعوا برؤية لإنشاء شيء أفضل. قمنا بدمج تكنولوجيا الذكاء الاصطناعي المتطورة مع الخبرة الثقافية العميقة لبناء منصة ترجمة تفهم السياق حقاً.
                    </p>
                </div>
            </div>
        </div>
    </section>

    <!-- Values Section -->
    <section class="py-20">
        <div class="container mx-auto px-6">
            <h2 class="text-4xl font-bold text-gray-900 mb-12 text-center">قيمنا</h2>
            <div class="grid md:grid-cols-3 gap-8">
                <div class="bg-white rounded-lg shadow-lg p-8 text-center">
                    <div class="text-5xl mb-4">🌍</div>
                    <h3 class="text-2xl font-bold text-gray-900 mb-4">الحساسية الثقافية</h3>
                    <p class="text-gray-700">
                        نحترم ونحافظ على الفروق الثقافية الدقيقة في كل ترجمة، مما يضمن أن رسالتك تلقى صدى حقيقياً لدى الجماهير المحلية.
                    </p>
                </div>
                <div class="bg-white rounded-lg shadow-lg p-8 text-center">
                    <div class="text-5xl mb-4">🚀</div>
                    <h3 class="text-2xl font-bold text-gray-900 mb-4">الابتكار</h3>
                    <p class="text-gray-700">
                        نواصل دفع حدود تكنولوجيا الترجمة بالذكاء الاصطناعي لتقديم نتائج أفضل وأسرع وأكثر دقة.
                    </p>
                </div>
                <div class="bg-white rounded-lg shadow-lg p-8 text-center">
                    <div class="text-5xl mb-4">🔒</div>
                    <h3 class="text-2xl font-bold text-gray-900 mb-4">الأمان والخصوصية</h3>
                    <p class="text-gray-700">
                        بياناتك مشفرة ومحمية. نحن لا نشارك محتواك مع أطراف ثالثة أو نستخدمه لتدريب نماذجنا.
                    </p>
                </div>
            </div>
        </div>
    </section>

    <!-- CTA Section -->
    <section class="bg-gradient-to-r from-indigo-600 to-purple-600 text-white py-20">
        <div class="container mx-auto px-6 text-center">
            <h2 class="text-4xl font-bold mb-4">انضم إلينا في رحلتنا</h2>
            <p class="text-xl mb-8">كن جزءاً من مستقبل التواصل العالمي</p>
            <a href="/" class="inline-block bg-white text-indigo-600 px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition">
                ابدأ اليوم
            </a>
        </div>
    </section>

    <!-- Footer -->
    <footer class="bg-gray-900 text-white py-12">
        <div class="container mx-auto px-6 text-center">
            <p>&copy; 2024 CulturalTranslate. جميع الحقوق محفوظة.</p>
        </div>
    </footer>
</body>
</html>
