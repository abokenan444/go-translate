<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (!Schema::hasTable('task_templates')) {
            return;
        }

        Schema::table('task_templates', function (Blueprint $table) {
            if (!Schema::hasColumn('task_templates', 'type')) {
                $table->string('type', 100)->default('translation')->after('id');
            }
        });
    }

    public function down(): void
    {
        if (!Schema::hasTable('task_templates')) {
            return;
        }

        Schema::table('task_templates', function (Blueprint $table) {
            if (Schema::hasColumn('task_templates', 'type')) {
                $table->dropColumn('type');
            }
        });
    }
};
