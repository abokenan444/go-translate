<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('task_templates', function (Blueprint $table) {
            $table->id();
            $table->string('task_code', 50)->unique(); // website_translation, ad_copy, email, etc.
            $table->string('task_name'); // ترجمة موقع, إعلان, بريد إلكتروني
            $table->string('task_name_en'); // Website Translation, Ad Copy, Email
            $table->string('category'); // translation, content_creation, rewriting, etc.
            $table->text('description')->nullable();
            
            // Task Type & Purpose
            $table->enum('type', ['translation', 'rewriting', 'creation', 'optimization', 'analysis'])->default('translation');
            $table->json('use_cases')->nullable(); // حالات الاستخدام
            
            // AI Prompt Template
            $table->text('system_prompt'); // System prompt للمهمة
            $table->text('user_prompt_template'); // قالب prompt المستخدم
            $table->json('prompt_variables')->nullable(); // متغيرات القالب
            
            // Requirements
            $table->json('required_fields')->nullable(); // حقول مطلوبة
            $table->json('optional_fields')->nullable(); // حقول اختيارية
            
            // Output Specifications
            $table->integer('min_length')->nullable(); // الحد الأدنى للطول
            $table->integer('max_length')->nullable(); // الحد الأقصى للطول
            $table->json('output_format')->nullable(); // تنسيق الإخراج
            
            // Cultural & Tone Settings
            $table->json('recommended_tones')->nullable(); // النبرات الموصى بها
            $table->json('recommended_cultures')->nullable(); // الثقافات الموصى بها
            $table->json('recommended_industries')->nullable(); // الصناعات الموصى بها
            
            // Quality Control
            $table->json('validation_rules')->nullable(); // قواعد التحقق
            $table->json('post_processing_steps')->nullable(); // خطوات ما بعد المعالجة
            
            // Examples
            $table->json('example_inputs')->nullable(); // أمثلة مدخلات
            $table->json('example_outputs')->nullable(); // أمثلة مخرجات
            
            // Pricing & Limits
            $table->integer('estimated_tokens')->default(500); // تقدير التوكنز
            $table->decimal('base_cost', 8, 4)->default(0.01); // التكلفة الأساسية
            
            // UI & UX
            $table->string('icon')->nullable();
            $table->string('color')->nullable();
            $table->json('ui_fields')->nullable(); // حقول الواجهة
            
            $table->boolean('is_active')->default(true);
            $table->boolean('is_featured')->default(false);
            $table->integer('priority')->default(0);
            $table->integer('usage_count')->default(0); // عدد مرات الاستخدام
            $table->timestamps();
            
            $table->index('task_code');
            $table->index('category');
            $table->index('type');
            $table->index('is_active');
            $table->index('is_featured');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('task_templates');
    }
};
