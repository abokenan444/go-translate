<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // جدول التكاملات
        if (!Schema::hasTable('integrations')) {
            Schema::create('integrations', function (Blueprint $table) {
                $table->id();
                $table->foreignId('company_id')->nullable()->constrained()->onDelete('cascade');
                $table->string('name');
                $table->string('type'); // api, webhook, oauth
                $table->string('provider'); // stripe, paypal, custom
                $table->text('description')->nullable();
                $table->string('api_key')->nullable();
                $table->string('api_secret')->nullable();
                $table->text('webhook_url')->nullable();
                $table->json('config')->nullable();
                $table->boolean('is_active')->default(true);
                $table->integer('request_count')->default(0);
                $table->timestamp('last_used_at')->nullable();
                $table->timestamps();
            });
        }

        // جدول سجل API
        if (!Schema::hasTable('api_logs')) {
            Schema::create('api_logs', function (Blueprint $table) {
                $table->id();
                $table->foreignId('integration_id')->nullable()->constrained()->onDelete('cascade');
                $table->foreignId('user_id')->nullable()->constrained()->onDelete('set null');
                $table->string('method'); // GET, POST, PUT, DELETE
                $table->string('endpoint');
                $table->text('request_data')->nullable();
                $table->text('response_data')->nullable();
                $table->integer('status_code')->nullable();
                $table->integer('response_time')->nullable(); // milliseconds
                $table->string('ip_address')->nullable();
                $table->timestamps();
            });
        }

        // جدول الإعدادات
        if (!Schema::hasTable('settings')) {
            Schema::create('settings', function (Blueprint $table) {
                $table->id();
                $table->string('key')->unique();
                $table->text('value')->nullable();
                $table->string('type')->default('string'); // string, boolean, json, array
                $table->string('group')->default('general'); // general, seo, email, payment, social
                $table->text('description')->nullable();
                $table->timestamps();
            });
        }

        // جدول المدفوعات
        if (!Schema::hasTable('payments')) {
            Schema::create('payments', function (Blueprint $table) {
                $table->id();
                $table->foreignId('user_id')->nullable()->constrained()->onDelete('set null');
                $table->foreignId('company_id')->nullable()->constrained()->onDelete('set null');
                $table->foreignId('subscription_plan_id')->nullable()->constrained()->onDelete('set null');
                $table->string('payment_method'); // stripe, bank_transfer
                $table->decimal('amount', 10, 2);
                $table->string('currency')->default('USD');
                $table->string('status')->default('pending'); // pending, completed, failed, refunded
                $table->string('transaction_id')->nullable();
                $table->string('stripe_payment_intent_id')->nullable();
                $table->text('bank_transfer_receipt')->nullable();
                $table->text('notes')->nullable();
                $table->timestamp('paid_at')->nullable();
                $table->timestamps();
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('payments');
        Schema::dropIfExists('settings');
        Schema::dropIfExists('api_logs');
        Schema::dropIfExists('integrations');
    }
};
