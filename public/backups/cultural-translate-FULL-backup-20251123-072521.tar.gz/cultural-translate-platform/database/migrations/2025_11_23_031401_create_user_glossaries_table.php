<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('user_glossaries', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->onDelete('cascade');
            $table->foreignId('company_id')->nullable()->constrained()->onDelete('cascade');
            
            $table->string('term'); // المصطلح
            $table->string('source_language', 10); // اللغة المصدر
            $table->string('target_language', 10); // اللغة الهدف
            $table->string('translation'); // الترجمة المفضلة
            
            // Context
            $table->text('context')->nullable(); // السياق
            $table->string('category')->nullable(); // الفئة
            $table->json('tags')->nullable(); // وسوم
            
            // Usage
            $table->boolean('is_mandatory')->default(false); // إجباري الاستخدام
            $table->boolean('is_case_sensitive')->default(false); // حساس لحالة الأحرف
            $table->integer('usage_count')->default(0);
            
            // Notes
            $table->text('notes')->nullable();
            
            $table->boolean('is_active')->default(true);
            $table->timestamps();
            
            $table->index(['user_id', 'source_language', 'target_language']);
            $table->index('term');
            $table->index('is_active');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('user_glossaries');
    }
};
