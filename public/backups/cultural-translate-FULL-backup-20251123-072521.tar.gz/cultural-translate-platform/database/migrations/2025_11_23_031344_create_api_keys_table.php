<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('api_keys', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->onDelete('cascade');
            $table->foreignId('company_id')->nullable()->constrained()->onDelete('cascade');
            
            $table->string('name'); // اسم المفتاح
            $table->string('key', 64)->unique(); // المفتاح
            $table->text('description')->nullable();
            
            // Permissions
            $table->json('allowed_endpoints')->nullable(); // الـ endpoints المسموح بها
            $table->json('allowed_languages')->nullable(); // اللغات المسموح بها
            $table->integer('rate_limit_per_minute')->default(60);
            $table->integer('rate_limit_per_day')->default(10000);
            
            // Usage Statistics
            $table->integer('total_requests')->default(0);
            $table->integer('successful_requests')->default(0);
            $table->integer('failed_requests')->default(0);
            $table->integer('total_tokens_used')->default(0);
            $table->timestamp('last_used_at')->nullable();
            
            // Security
            $table->json('allowed_ips')->nullable(); // IPs المسموح بها
            $table->json('allowed_domains')->nullable(); // Domains المسموح بها
            
            // Status
            $table->boolean('is_active')->default(true);
            $table->timestamp('expires_at')->nullable();
            
            $table->timestamps();
            
            $table->index('key');
            $table->index('user_id');
            $table->index('is_active');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('api_keys');
    }
};
