<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('industry_templates', function (Blueprint $table) {
            $table->id();
            $table->string('industry_code', 50)->unique(); // tourism, marketing, ecommerce, etc.
            $table->string('industry_name'); // السياحة, التسويق, التجارة الإلكترونية
            $table->string('industry_name_en'); // Tourism, Marketing, E-commerce
            $table->text('description')->nullable();
            
            // Industry Specifics
            $table->json('common_terms')->nullable(); // مصطلحات شائعة
            $table->json('glossary')->nullable(); // قاموس مصطلحات خاص
            $table->json('preferred_tones')->nullable(); // النبرات المفضلة
            $table->json('cultural_considerations')->nullable(); // اعتبارات ثقافية
            
            // Content Types
            $table->json('content_types')->nullable(); // أنواع المحتوى (ads, emails, product descriptions)
            
            // AI Instructions
            $table->text('system_prompt')->nullable(); // System prompt خاص بالصناعة
            $table->json('translation_rules')->nullable(); // قواعد الترجمة
            $table->json('quality_criteria')->nullable(); // معايير الجودة
            
            // Examples
            $table->json('example_translations')->nullable(); // أمثلة ترجمات
            
            // SEO & Marketing
            $table->json('seo_keywords')->nullable(); // كلمات SEO
            $table->json('marketing_phrases')->nullable(); // عبارات تسويقية
            
            // Visual Identity
            $table->string('icon')->nullable();
            $table->string('color')->nullable();
            
            $table->boolean('is_active')->default(true);
            $table->integer('priority')->default(0);
            $table->timestamps();
            
            $table->index('industry_code');
            $table->index('is_active');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('industry_templates');
    }
};
