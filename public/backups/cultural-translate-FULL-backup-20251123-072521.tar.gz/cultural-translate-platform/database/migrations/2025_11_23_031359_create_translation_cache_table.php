<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('translation_cache', function (Blueprint $table) {
            $table->id();
            
            // Cache Key Components
            $table->string('cache_key', 64)->unique(); // MD5 hash of all parameters
            $table->text('source_text');
            $table->string('source_language', 10);
            $table->string('target_language', 10);
            $table->string('tone', 50)->nullable();
            $table->string('industry', 50)->nullable();
            $table->string('task_type', 50)->nullable();
            
            // Cached Result
            $table->text('translated_text');
            $table->json('metadata')->nullable(); // معلومات إضافية
            
            // Performance
            $table->integer('tokens_used')->default(0);
            $table->integer('response_time_ms')->default(0);
            
            // Usage Statistics
            $table->integer('hit_count')->default(1); // عدد مرات الاستخدام
            $table->timestamp('last_used_at')->useCurrent();
            
            // Quality
            $table->decimal('quality_score', 3, 2)->nullable(); // 0.00 - 1.00
            
            // Expiration
            $table->timestamp('expires_at')->nullable();
            
            $table->timestamps();
            
            $table->index('cache_key');
            $table->index(['source_language', 'target_language']);
            $table->index('last_used_at');
            $table->index('expires_at');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('translation_cache');
    }
};
