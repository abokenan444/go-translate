<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('cultural_profiles', function (Blueprint $table) {
            $table->id();
            $table->string('culture_code', 10)->unique(); // ar, en, fr, es, etc.
            $table->string('culture_name'); // العربية, English, etc.
            $table->string('native_name'); // الاسم بلغته الأصلية
            $table->text('description')->nullable();
            
            // Cultural Characteristics
            $table->json('characteristics')->nullable(); // خصائص الثقافة
            $table->json('preferred_tones')->nullable(); // النبرات المفضلة
            $table->json('taboos')->nullable(); // المحظورات
            $table->json('special_styles')->nullable(); // الأساليب الخاصة
            $table->json('symbols_references')->nullable(); // الرموز والمراجع
            
            // Formality & Communication Style
            $table->enum('formality_level', ['very_formal', 'formal', 'neutral', 'casual', 'very_casual'])->default('neutral');
            $table->enum('directness', ['very_direct', 'direct', 'moderate', 'indirect', 'very_indirect'])->default('moderate');
            $table->boolean('uses_honorifics')->default(false);
            
            // Emotional Expression
            $table->integer('emotional_expressiveness')->default(5); // 1-10 scale
            $table->json('common_expressions')->nullable(); // تعبيرات شائعة
            
            // Business & Marketing
            $table->json('marketing_preferences')->nullable();
            $table->json('business_etiquette')->nullable();
            
            // Language Specifics
            $table->string('text_direction', 3)->default('ltr'); // ltr or rtl
            $table->json('date_formats')->nullable();
            $table->json('number_formats')->nullable();
            $table->string('currency_symbol', 10)->nullable();
            
            // AI Prompting
            $table->text('system_prompt')->nullable(); // System prompt خاص بالثقافة
            $table->text('translation_guidelines')->nullable(); // إرشادات الترجمة
            
            $table->boolean('is_active')->default(true);
            $table->integer('priority')->default(0); // للترتيب
            $table->timestamps();
            
            $table->index('culture_code');
            $table->index('is_active');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('cultural_profiles');
    }
};
