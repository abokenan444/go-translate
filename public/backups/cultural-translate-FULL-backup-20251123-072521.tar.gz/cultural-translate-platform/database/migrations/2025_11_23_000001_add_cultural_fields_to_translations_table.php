<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (!Schema::hasTable('translations')) {
            return;
        }

        Schema::table('translations', function (Blueprint $table) {
            if (!Schema::hasColumn('translations', 'source_text')) {
                $table->longText('source_text')->nullable()->after('id');
            }
            if (!Schema::hasColumn('translations', 'translated_text')) {
                $table->longText('translated_text')->nullable()->after('source_text');
            }
            if (!Schema::hasColumn('translations', 'tone')) {
                $table->string('tone', 100)->nullable()->after('translated_text');
            }
            if (!Schema::hasColumn('translations', 'context')) {
                $table->string('context', 255)->nullable()->after('tone');
            }
            if (!Schema::hasColumn('translations', 'word_count')) {
                $table->unsignedInteger('word_count')->nullable()->after('context');
            }
            if (!Schema::hasColumn('translations', 'culture_id')) {
                $table->unsignedBigInteger('culture_id')->nullable()->after('word_count');
            }
            if (!Schema::hasColumn('translations', 'tone_id')) {
                $table->unsignedBigInteger('tone_id')->nullable()->after('culture_id');
            }
            if (!Schema::hasColumn('translations', 'industry_id')) {
                $table->unsignedBigInteger('industry_id')->nullable()->after('tone_id');
            }
            if (!Schema::hasColumn('translations', 'task_template_id')) {
                $table->unsignedBigInteger('task_template_id')->nullable()->after('industry_id');
            }
        });
    }

    public function down(): void
    {
        if (!Schema::hasTable('translations')) {
            return;
        }

        Schema::table('translations', function (Blueprint $table) {
            foreach ([
                'source_text',
                'translated_text',
                'tone',
                'context',
                'word_count',
                'culture_id',
                'tone_id',
                'industry_id',
                'task_template_id',
            ] as $col) {
                if (Schema::hasColumn('translations', $col)) {
                    $table->dropColumn($col);
                }
            }
        });
    }
};
