<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('emotional_tones', function (Blueprint $table) {
            $table->id();
            $table->string('tone_code', 50)->unique(); // professional, friendly, formal, etc.
            $table->string('tone_name'); // احترافي, ودي, رسمي
            $table->string('tone_name_en'); // Professional, Friendly, Formal
            $table->text('description')->nullable();
            
            // Tone Characteristics
            $table->integer('formality_score')->default(5); // 1-10
            $table->integer('warmth_score')->default(5); // 1-10
            $table->integer('enthusiasm_score')->default(5); // 1-10
            $table->integer('directness_score')->default(5); // 1-10
            
            // AI Instructions
            $table->text('system_instructions'); // تعليمات للـ AI
            $table->json('keywords_to_use')->nullable(); // كلمات مفتاحية للاستخدام
            $table->json('keywords_to_avoid')->nullable(); // كلمات يجب تجنبها
            $table->json('sentence_patterns')->nullable(); // أنماط الجمل
            
            // Examples
            $table->json('good_examples')->nullable(); // أمثلة جيدة
            $table->json('bad_examples')->nullable(); // أمثلة سيئة
            
            // Usage Context
            $table->json('suitable_for')->nullable(); // مناسب لـ (industries, situations)
            $table->json('not_suitable_for')->nullable(); // غير مناسب لـ
            
            // Emoji & Symbols
            $table->string('icon')->nullable(); // أيقونة
            $table->string('color')->nullable(); // لون مميز
            
            $table->boolean('is_active')->default(true);
            $table->integer('priority')->default(0);
            $table->timestamps();
            
            $table->index('tone_code');
            $table->index('is_active');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('emotional_tones');
    }
};
