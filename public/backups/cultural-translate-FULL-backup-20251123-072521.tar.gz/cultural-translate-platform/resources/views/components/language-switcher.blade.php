<div x-data="{ open: false }" class="relative inline-block text-left" @click.away="open = false">
    @php
        $currentLocale = app()->getLocale();
        $languages = [
            'ar' => ['name' => 'العربية', 'flag' => '🇸🇦', 'short' => 'AR', 'dir' => 'rtl'],
            'en' => ['name' => 'English', 'flag' => '🇬🇧', 'short' => 'EN', 'dir' => 'ltr'],
            'fr' => ['name' => 'Français', 'flag' => '🇫🇷', 'short' => 'FR', 'dir' => 'ltr'],
            'es' => ['name' => 'Español', 'flag' => '🇪🇸', 'short' => 'ES', 'dir' => 'ltr'],
            'de' => ['name' => 'Deutsch', 'flag' => '🇩🇪', 'short' => 'DE', 'dir' => 'ltr'],
            'it' => ['name' => 'Italiano', 'flag' => '🇮🇹', 'short' => 'IT', 'dir' => 'ltr'],
            'pt' => ['name' => 'Português', 'flag' => '🇵🇹', 'short' => 'PT', 'dir' => 'ltr'],
            'ru' => ['name' => 'Русский', 'flag' => '🇷🇺', 'short' => 'RU', 'dir' => 'ltr'],
            'zh' => ['name' => '中文', 'flag' => '🇨🇳', 'short' => 'ZH', 'dir' => 'ltr'],
            'ja' => ['name' => '日本語', 'flag' => '🇯🇵', 'short' => 'JA', 'dir' => 'ltr'],
            'ko' => ['name' => '한국어', 'flag' => '🇰🇷', 'short' => 'KO', 'dir' => 'ltr'],
            'tr' => ['name' => 'Türkçe', 'flag' => '🇹🇷', 'short' => 'TR', 'dir' => 'ltr'],
            'nl' => ['name' => 'Nederlands', 'flag' => '🇳🇱', 'short' => 'NL', 'dir' => 'ltr'],
        ];
    @endphp

    <!-- Language Button -->
    <button 
        @click="open = !open" 
        type="button" 
        class="inline-flex items-center gap-2 px-3 py-2 text-sm font-medium text-gray-700 dark:text-gray-200 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-colors duration-200"
        aria-expanded="false"
        aria-haspopup="true"
    >
        <!-- Mobile: Globe Icon -->
        <svg class="w-5 h-5 sm:hidden" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
        </svg>
        <span class="text-sm font-semibold sm:hidden">{{ $languages[$currentLocale]['short'] }}</span>
        
        <!-- Desktop: Flag + Name -->
        <span class="hidden sm:flex items-center gap-2">
            <span class="text-lg">{{ $languages[$currentLocale]['flag'] }}</span>
            <span>{{ $languages[$currentLocale]['name'] }}</span>
        </span>
        
        <!-- Arrow -->
        <svg class="w-4 h-4 transition-transform duration-200" :class="{'rotate-180': open}" fill="currentColor" viewBox="0 0 20 20">
            <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd"></path>
        </svg>
    </button>

    <!-- Dropdown Menu -->
    <div 
        x-show="open"
        x-transition:enter="transition ease-out duration-100"
        x-transition:enter-start="transform opacity-0 scale-95"
        x-transition:enter-end="transform opacity-100 scale-100"
        x-transition:leave="transition ease-in duration-75"
        x-transition:leave-start="transform opacity-100 scale-100"
        x-transition:leave-end="transform opacity-0 scale-95"
        class="absolute right-0 mt-2 w-56 origin-top-right bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none z-[9999] max-h-[400px] overflow-y-auto"
        role="menu"
        aria-orientation="vertical"
        style="display: none;"
    >
        <div class="py-1" role="none">
            @foreach($languages as $code => $lang)
                <a 
                    href="{{ route('language.switch', $code) }}" 
                    class="flex items-center gap-3 px-4 py-3 text-sm text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors duration-150 {{ $currentLocale === $code ? 'bg-blue-50 dark:bg-blue-900/20' : '' }}"
                    role="menuitem"
                    dir="{{ $lang['dir'] }}"
                >
                    <span class="text-xl">{{ $lang['flag'] }}</span>
                    <span class="flex-1 {{ $currentLocale === $code ? 'font-semibold' : '' }}">{{ $lang['name'] }}</span>
                    @if($currentLocale === $code)
                        <svg class="w-5 h-5 text-blue-600 dark:text-blue-400" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"></path>
                        </svg>
                    @endif
                </a>
            @endforeach
        </div>
    </div>
</div>
