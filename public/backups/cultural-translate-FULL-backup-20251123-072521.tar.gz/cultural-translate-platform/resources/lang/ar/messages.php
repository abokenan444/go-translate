<?php

return [
    // Navigation
    'Features' => 'الميزات',
    'Pricing' => 'الأسعار',
    'Use Cases' => 'حالات الاستخدام',
    'API Docs' => 'وثائق API',
    'Login' => 'تسجيل الدخول',
    'Sign Up' => 'إنشاء حساب',
    'Get Started' => 'ابدأ الآن',
    
    // Home Page
    'AI-Powered Cultural Translation' => 'ترجمة ثقافية مدعومة بالذكاء الاصطناعي',
    'Translate content in 13 languages while preserving cultural context, brand voice, and meaning. Trusted by 10,000+ teams worldwide.' => 'ترجم المحتوى إلى 13 لغة مع الحفاظ على السياق الثقافي وصوت العلامة التجارية والمعنى. موثوق به من قبل أكثر من 10,000 فريق حول العالم.',
    'Start Free Trial' => 'ابدأ تجربة مجانية',
    'Watch Demo' => 'شاهد العرض التوضيحي',
    'No credit card required' => 'لا حاجة لبطاقة ائتمان',
    '14-day free trial' => 'تجربة مجانية لمدة 14 يومًا',
    
    // Stats
    'Active Users' => 'مستخدم نشط',
    'Languages' => 'لغة',
    'Words Translated' => 'كلمة مترجمة',
    'Uptime SLA' => 'وقت التشغيل',
    
    // Features Section
    'Powerful Features' => 'ميزات قوية',
    'Everything you need to translate content while preserving cultural context and brand voice' => 'كل ما تحتاجه لترجمة المحتوى مع الحفاظ على السياق الثقافي وصوت العلامة التجارية',
    
    'Cultural Adaptation' => 'التكيف الثقافي',
    'AI-powered cultural context preservation ensures your message resonates with local audiences' => 'الحفاظ على السياق الثقافي المدعوم بالذكاء الاصطناعي يضمن أن رسالتك تلقى صدى لدى الجماهير المحلية',
    
    'Lightning Fast' => 'سريع للغاية',
    'Translate thousands of words in seconds with our optimized AI models' => 'ترجم آلاف الكلمات في ثوانٍ باستخدام نماذج الذكاء الاصطناعي المحسّنة لدينا',
    
    'Enterprise Security' => 'أمان المؤسسات',
    'GDPR compliant, SOC 2 Type II certified, with end-to-end encryption' => 'متوافق مع GDPR، معتمد SOC 2 Type II، مع تشفير من طرف إلى طرف',
    
    'Translation Memory' => 'ذاكرة الترجمة',
    'Save costs by reusing previous translations and maintaining consistency' => 'وفر التكاليف عن طريق إعادة استخدام الترجمات السابقة والحفاظ على الاتساق',
    
    'Custom Glossaries' => 'مسارد مخصصة',
    'Define brand-specific terminology for consistent translations' => 'حدد المصطلحات الخاصة بالعلامة التجارية للترجمات المتسقة',
    
    'Developer-Friendly API' => 'API صديق للمطورين',
    'RESTful API with SDKs in 7 languages and comprehensive documentation' => 'RESTful API مع SDKs بـ 7 لغات ووثائق شاملة',
    
    // CTA Section
    'Ready to Go Global?' => 'هل أنت مستعد للانتشار العالمي؟',
    'Join 10,000+ teams using CulturalTranslate to reach global audiences' => 'انضم إلى أكثر من 10,000 فريق يستخدمون CulturalTranslate للوصول إلى الجماهير العالمية',
    'Contact Sales' => 'اتصل بالمبيعات',
    
    // Footer
    'Product' => 'المنتج',
    'Integrations' => 'التكاملات',
    'Company' => 'الشركة',
    'About' => 'عن الشركة',
    'Blog' => 'المدونة',
    'Careers' => 'الوظائف',
    'Contact' => 'اتصل بنا',
    'Resources' => 'الموارد',
    'Help Center' => 'مركز المساعدة',
    'Guides' => 'الأدلة',
    'Case Studies' => 'دراسات الحالة',
    'Status' => 'الحالة',
    'Legal' => 'قانوني',
    'Privacy' => 'الخصوصية',
    'Terms' => 'الشروط',
    'Security' => 'الأمان',
    'GDPR' => 'GDPR',
    
    // Legal Pages
    'Privacy Policy' => 'سياسة الخصوصية',
    'Terms of Service' => 'شروط الخدمة',
    '1. Information We Collect' => '1. المعلومات التي نجمعها',
    'We collect information you provide directly to us, including name, email, and usage data.' => 'نجمع المعلومات التي تقدمها لنا مباشرة، بما في ذلك الاسم والبريد الإلكتروني وبيانات الاستخدام.',
    '2. How We Use Your Information' => '2. كيف نستخدم معلوماتك',
    'We use the information we collect to provide, maintain, and improve our services.' => 'نستخدم المعلومات التي نجمعها لتوفير خدماتنا وصيانتها وتحسينها.',
    '3. Data Security' => '3. أمان البيانات',
    'We implement appropriate security measures to protect your personal information.' => 'نطبق تدابير أمنية مناسبة لحماية معلوماتك الشخصية.',
    '4. Your Rights' => '4. حقوقك',
    'You have the right to access, update, or delete your personal information.' => 'لديك الحق في الوصول إلى معلوماتك الشخصية أو تحديثها أو حذفها.',
    
    '1. Acceptance of Terms' => '1. قبول الشروط',
    'By accessing our service, you agree to be bound by these terms.' => 'من خلال الوصول إلى خدمتنا، فإنك توافق على الالتزام بهذه الشروط.',
    '2. Use License' => '2. ترخيص الاستخدام',
    'We grant you a limited license to use our translation services.' => 'نمنحك ترخيصًا محدودًا لاستخدام خدمات الترجمة الخاصة بنا.',
    '3. Service Availability' => '3. توفر الخدمة',
    'We strive to maintain 99.9% uptime but do not guarantee uninterrupted service.' => 'نسعى جاهدين للحفاظ على وقت تشغيل بنسبة 99.9٪ ولكننا لا نضمن خدمة غير منقطعة.',
];
