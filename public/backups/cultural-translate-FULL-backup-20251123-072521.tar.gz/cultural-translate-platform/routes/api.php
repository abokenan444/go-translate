<?php
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\ApiTranslationController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Cultural Translate Platform API v2.0
| Base URL: https://culturaltranslate.com/api/v2
|
*/

// Public Demo Translation (no authentication required)
Route::post('/demo-translate', [ApiTranslationController::class, 'demoTranslate']);

// Public endpoints
Route::prefix('v2')->group(function () {
    
    // Health check
    Route::get('/health', [ApiTranslationController::class, 'health']);
    
    // Get supported languages
    Route::get('/languages', [ApiTranslationController::class, 'languages']);
    
    // Get available tones
    Route::get('/tones', [ApiTranslationController::class, 'tones']);
    
    // Protected endpoints (require API key)
    Route::middleware('auth:sanctum')->group(function () {
        
        // Translate text
        Route::post('/translate', [ApiTranslationController::class, 'translate']);
        
        // Detect language
        Route::post('/detect', [ApiTranslationController::class, 'detectLanguage']);
        
        // Get usage statistics
        Route::get('/stats', [ApiTranslationController::class, 'stats']);
    });
});
