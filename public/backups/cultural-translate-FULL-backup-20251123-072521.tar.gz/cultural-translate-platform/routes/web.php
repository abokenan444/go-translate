<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\LanguageController;

/*
|--------------------------------------------------------------------------
| Admin Subdomain Routes
|--------------------------------------------------------------------------
// | Routes for admin.culturaltranslate.com subdomain
// | Redirects to Filament Admin Panel
// */
// 
// Route::domain('admin.culturaltranslate.com')->group(function () {
//     Route::get('/', function () {
//         return redirect()->route('filament.admin.pages.dashboard');
//     });
// });

/*
|--------------------------------------------------------------------------
| Main Website Routes
|--------------------------------------------------------------------------
| Routes for culturaltranslate.com main domain
*/

// Language Switcher
Route::get('/language/{locale}', [LanguageController::class, 'switch'])->name('language.switch');

// Landing Page
Route::get('/', function () {
    return view('landing');
})->name('home');

// Public Pages
Route::get('/features', function () {
    return view('pages.features');
})->name('features');

Route::get('/pricing', [\App\Http\Controllers\PricingController::class, 'index'])->name('pricing');
Route::post('/contact-custom-plan', [\App\Http\Controllers\PricingController::class, 'contactCustomPlan'])->name('pricing.contact-custom');

Route::get('/use-cases', function () {
    return view('pages.use-cases');
})->name('use-cases');

Route::get('/api-docs', function () {
    return view('pages.api-docs');
})->name('api-docs');

Route::get('/about', function () {
    return view('pages.about');
})->name('about');

Route::get('/contact', function () {
    return view('pages.contact');
})->name('contact');

Route::get('/blog', function () {
    return view('pages.blog');
})->name('blog');

Route::get('/integrations', function () {
    return view('pages.integrations');
})->name('integrations');

// Complaints
Route::get('/complaints', [\App\Http\Controllers\ComplaintController::class, 'index'])->name('complaints');
Route::post('/complaints/submit', [\App\Http\Controllers\ComplaintController::class, 'submit'])->name('complaints.submit');
Route::get('/complaints/track', [\App\Http\Controllers\ComplaintController::class, 'track'])->name('complaints.track');

// Dashboard for authenticated users
Route::middleware(['auth'])->group(function () {
    Route::get('/dashboard', function () {
        return view('dashboard.app');
    })->name('dashboard');
});

/*
|--------------------------------------------------------------------------
| OLD ROUTES - COMMENTED OUT (Replaced by Filament Admin Panel)
|--------------------------------------------------------------------------
| These routes are no longer used as we've migrated to Filament
| Keeping them commented for reference
*/

// OLD: Admin Dashboard Routes (replaced by Filament)
// Route::middleware(['auth'])->prefix('admin-dashboard')->group(function () {
//     Route::get('/dashboard', [\App\Http\Controllers\Admin\AdminDashboardController::class, 'index'])
//         ->name('admin.dashboard');
// });

// OLD: Admin Dashboard (Tailwind + Flowbite) (replaced by Filament)
// Route::middleware(['auth'])
//     ->prefix('admin-dashboard')
//     ->name('admin.')
//     ->group(function () {
//         Route::get('/dashboard', [\App\Http\Controllers\Admin\DashboardController::class, 'index'])
//             ->name('dashboard');
//     });

// OLD: AI Dev Chat Routes (replaced by Filament Pages)
// Route::middleware(['auth', 'admin'])
//     ->prefix('admin')
//     ->name('admin.')
//     ->group(function () {
//         Route::get('ai-dev-chat', [\App\Http\Controllers\Admin\AIAgentChatController::class, 'index'])
//             ->name('ai-agent-chat.index');
//
//         Route::post('ai-dev-chat', [\App\Http\Controllers\Admin\AIAgentChatController::class, 'send'])
//             ->name('ai-agent-chat.send');
//     });

// Legal & Info Pages
Route::get('/privacy', function () {
    return view('pages.privacy');
})->name('privacy');

Route::get('/terms', function () {
    return view('pages.terms');
})->name('terms');

Route::get('/security', function () {
    return view('pages.security');
})->name('security');

Route::get('/gdpr', function () {
    return view('pages.gdpr');
})->name('gdpr');

Route::get('/help-center', function () {
    return view('pages.help-center');
})->name('help-center');

Route::get('/guides', function () {
    return view('pages.guides');
})->name('guides');

Route::get('/status', function () {
    return view('pages.status');
})->name('status');

Route::get('/careers', function () {
    return view('pages.careers');
})->name('careers');

Route::get('/_temp_admin_login', function () {
    $user = App\Models\User::where('email', 'admin@culturaltranslate.com')->first();
    if ($user) {
        Auth::login($user);
        return redirect('/admin-dashboard');
    }
    return 'User not found';
});


require __DIR__.'/ai_developer.php';
require __DIR__.'/auth.php';

// Translation Routes
require __DIR__.'/translation.php';

// Demo Translation (Public)
Route::post('/api/demo-translate', [App\Http\Controllers\DemoController::class, 'translate'])->name('api.demo-translate');

// Cultural Prompt Engine Routes
Route::middleware(['web', 'auth'])
    ->prefix('admin/cultural-prompts')
    ->group(function () {
        Route::view('/', 'admin.cultural_prompts.index')
            ->name('admin.cultural-prompts.index');

        Route::post('/preview', [\App\Http\Controllers\CulturalPromptController::class, 'preview'])
            ->name('admin.cultural-prompts.preview');
    });
Route::get('/language/{locale}', [App\Http\Controllers\LanguageController::class, 'switch'])->name('language.switch');
