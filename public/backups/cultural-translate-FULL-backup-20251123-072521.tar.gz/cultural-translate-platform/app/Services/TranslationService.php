<?php

namespace App\Services;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class TranslationService
{
    protected $apiKey;
    protected $model = 'gpt-4o-mini';

    public function __construct()
    {
        $this->apiKey = env('OPENAI_API_KEY');
    }

    /**
     * Translate text with cultural context
     */
    public function translateCultural($text, $sourceLang, $targetLang, $context = null, $tone = 'professional')
    {
        $prompt = $this->buildCulturalPrompt($text, $sourceLang, $targetLang, $context, $tone);

        try {
            $response = Http::withHeaders([
                'Authorization' => 'Bearer ' . $this->apiKey,
                'Content-Type' => 'application/json',
            ])->timeout(60)->post('https://api.openai.com/v1/chat/completions', [
                'model' => $this->model,
                'messages' => [
                    [
                        'role' => 'system',
                        'content' => 'You are a professional cultural translator. Your job is to translate text while preserving cultural context, emotional tone, and brand voice. Always provide natural, culturally appropriate translations that resonate with the target audience.'
                    ],
                    [
                        'role' => 'user',
                        'content' => $prompt
                    ]
                ],
                'temperature' => 0.7,
                'max_tokens' => 2000,
            ]);

            if ($response->successful()) {
                $data = $response->json();
                $translation = $data['choices'][0]['message']['content'] ?? '';
                
                return [
                    'success' => true,
                    'translation' => trim($translation),
                    'source_text' => $text,
                    'source_lang' => $sourceLang,
                    'target_lang' => $targetLang,
                    'tokens_used' => $data['usage']['total_tokens'] ?? 0,
                ];
            }

            return [
                'success' => false,
                'error' => 'API request failed',
                'message' => $response->body()
            ];

        } catch (\Exception $e) {
            Log::error('Translation error: ' . $e->getMessage());
            return [
                'success' => false,
                'error' => 'Translation failed',
                'message' => $e->getMessage()
            ];
        }
    }

    /**
     * Build cultural translation prompt
     */
    protected function buildCulturalPrompt($text, $sourceLang, $targetLang, $context, $tone)
    {
        $languageNames = [
            'en' => 'English',
            'ar' => 'Arabic',
            'es' => 'Spanish',
            'fr' => 'French',
            'de' => 'German',
            'it' => 'Italian',
            'pt' => 'Portuguese',
            'ru' => 'Russian',
            'zh' => 'Chinese',
            'ja' => 'Japanese',
            'ko' => 'Korean',
            'tr' => 'Turkish',
            'hi' => 'Hindi',
        ];

        $sourceLanguage = $languageNames[$sourceLang] ?? $sourceLang;
        $targetLanguage = $languageNames[$targetLang] ?? $targetLang;

        $prompt = "Translate the following text from {$sourceLanguage} to {$targetLanguage}.\n\n";
        $prompt .= "**Important Instructions:**\n";
        $prompt .= "- Preserve the cultural context and emotional tone\n";
        $prompt .= "- Adapt idioms and expressions to be culturally appropriate\n";
        $prompt .= "- Maintain the brand voice and style\n";
        $prompt .= "- Use natural, native-sounding language\n";
        $prompt .= "- Keep the same level of formality: {$tone}\n";
        
        if ($context) {
            $prompt .= "- Context: {$context}\n";
        }
        
        $prompt .= "\n**Text to translate:**\n{$text}\n\n";
        $prompt .= "**Translation:**";

        return $prompt;
    }

    /**
     * Detect language
     */
    public function detectLanguage($text)
    {
        try {
            $response = Http::withHeaders([
                'Authorization' => 'Bearer ' . $this->apiKey,
                'Content-Type' => 'application/json',
            ])->timeout(30)->post('https://api.openai.com/v1/chat/completions', [
                'model' => $this->model,
                'messages' => [
                    [
                        'role' => 'system',
                        'content' => 'You are a language detection expert. Respond with only the ISO 639-1 language code (e.g., en, ar, es, fr).'
                    ],
                    [
                        'role' => 'user',
                        'content' => "Detect the language of this text and respond with only the language code:\n\n{$text}"
                    ]
                ],
                'temperature' => 0.3,
                'max_tokens' => 10,
            ]);

            if ($response->successful()) {
                $data = $response->json();
                $langCode = trim($data['choices'][0]['message']['content'] ?? 'en');
                return strtolower($langCode);
            }

            return 'en'; // Default to English

        } catch (\Exception $e) {
            Log::error('Language detection error: ' . $e->getMessage());
            return 'en';
        }
    }

    /**
     * Get supported languages
     */
    public function getSupportedLanguages()
    {
        return [
            'en' => 'English',
            'ar' => 'العربية',
            'es' => 'Español',
            'fr' => 'Français',
            'de' => 'Deutsch',
            'it' => 'Italiano',
            'pt' => 'Português',
            'ru' => 'Русский',
            'zh' => '中文',
            'ja' => '日本語',
            'ko' => '한국어',
            'tr' => 'Türkçe',
            'hi' => 'हिन्दी',
        ];
    }

    /**
     * Get tone options
     */
    public function getToneOptions()
    {
        return [
            'professional' => 'Professional',
            'casual' => 'Casual',
            'formal' => 'Formal',
            'friendly' => 'Friendly',
            'technical' => 'Technical',
            'marketing' => 'Marketing',
            'creative' => 'Creative',
        ];
    }
}
