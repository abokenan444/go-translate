<?php

namespace App\Services;

use App\Models\Culture;
use App\Models\Tone;
use App\Models\Industry;
use App\Models\TaskTemplate;
use App\Models\PromptPreset;
use Illuminate\Support\Arr;

class CulturalPromptEngine
{
    public function buildPrompt(array $payload): array
    {
        $culture = Culture::where('slug', $payload['culture_slug'] ?? null)->first();
        $tone    = Tone::where('slug', $payload['tone_slug'] ?? null)->first();
        $industry = Industry::where('slug', $payload['industry_slug'] ?? null)->first();
        $task     = TaskTemplate::where('slug', $payload['task_slug'] ?? null)->first();

        if (! $culture || ! $tone || ! $task) {
            throw new \RuntimeException('Missing culture, tone, or task template for prompt generation.');
        }

        $preset = null;
        if (! empty($payload['preset_slug'])) {
            $preset = PromptPreset::where('slug', $payload['preset_slug'])->first();
        }

        $systemPieces = [];

        $systemPieces[] = 'You are a senior cultural and emotional localization expert.';

        $systemPieces[] = 'Target culture: '.$culture->name.' (region: '.($culture->region ?? 'n/a').').';

        if ($culture->traits) {
            $traits = implode(', ', Arr::wrap($culture->traits));
            $systemPieces[] = 'Cultural traits to respect: '.$traits.'.';
        }

        $systemPieces[] = 'Tone: '.$tone->name.' – '.$tone->description;

        if ($industry) {
            $systemPieces[] = 'Industry / domain: '.$industry->name.'.';
        }

        if ($preset && $preset->system_prompt) {
            $systemPieces[] = $preset->system_prompt;
        }

        $systemPrompt = implode("\n", $systemPieces);

        $userPrompt = $task->base_prompt ?? 'Translate the following text preserving meaning and emotional impact.';

        $replacements = [
            '{source_lang}'   => $payload['source_language'] ?? 'ar',
            '{target_lang}'   => $payload['target_language'] ?? 'en',
            '{tone}'          => $tone->name,
            '{industry}'      => $industry->name ?? 'General',
            '{culture_name}'  => $culture->name,
            '{region}'        => $culture->region ?? '',
        ];

        $userPrompt = strtr($userPrompt, $replacements);

        if ($preset && $preset->user_prompt_template) {
            $extra = strtr($preset->user_prompt_template, $replacements);
            $userPrompt .= "\n\n".$extra;
        }

        return [
            'system' => $systemPrompt,
            'user'   => $userPrompt,
        ];
    }
}
