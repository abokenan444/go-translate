<?php

namespace App\Filament\Admin\Resources\EmotionalToneResource\Pages;

use App\Filament\Admin\Resources\EmotionalToneResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateEmotionalTone extends CreateRecord
{
    protected static string $resource = EmotionalToneResource::class;
}
