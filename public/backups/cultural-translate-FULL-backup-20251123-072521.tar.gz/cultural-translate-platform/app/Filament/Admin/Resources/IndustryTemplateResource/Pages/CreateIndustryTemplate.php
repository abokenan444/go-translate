<?php

namespace App\Filament\Admin\Resources\IndustryTemplateResource\Pages;

use App\Filament\Admin\Resources\IndustryTemplateResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateIndustryTemplate extends CreateRecord
{
    protected static string $resource = IndustryTemplateResource::class;
}
